# secrets/

Two files, and nothing else:

- `secrets.enc` — `~/.secrets.env`, `~/.git-credentials` and
  `~/.config/rclone/rclone.conf`, encrypted with a passphrase so the
  credentials can travel inside the bundle. `setup.sh` offers to unlock it on
  a new machine; `srvunlock` does it later.
- `secrets.env.example` — the template `setup.sh` seeds `~/.secrets.env` from
  when there is no blob to unlock.

Create or refresh the blob with:

```bash
srvlock          # or: ./secrets.sh lock
```

You will be offered a generated passphrase — take it and put it in your
password manager. Then commit the file and rebuild the bundle. A blob locked
with a passphrase the check called weak is marked so in its header, and
`make-bundle.sh` leaves it out of the zip; carry it by `scp` instead.

`make-bundle.sh` ships only these two files and this README from here, and
refuses to build if a plaintext `secrets.env` has turned up anywhere.
