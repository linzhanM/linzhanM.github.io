# secrets/

`secrets.enc` lives here: `~/.secrets.env` encrypted with a passphrase, so
the API tokens can travel inside the bundle.

It is not here yet. Create it with:

```bash
srvlock          # or: ./tools/secrets.sh lock
```

You will be offered a generated passphrase — take it and put it in your
password manager. Then commit the file and rebuild the bundle.

Nothing else belongs in this directory. Plaintext `secrets.env` is blocked by
`.gitignore` and `make-bundle.sh` refuses to build if it finds one.
