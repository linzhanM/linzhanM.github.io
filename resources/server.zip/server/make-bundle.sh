#!/usr/bin/env bash
# make-bundle.sh — build server.zip, the copy-to-a-new-machine artefact.
#
#   ./make-bundle.sh [output.zip] [--no-secrets]
#
# The zip contains this whole directory except the git history and anything
# secret. Unzipping it in $HOME on a new machine and running ./server/setup.sh
# configures that machine completely.
#
# Build it on a machine whose bundle is still complete: setup.sh prunes the
# profiles a machine does not use, so a bundle rebuilt on a pruned copy will
# not carry the other clusters. `git -C ~/server log` shows whether a prune
# has happened here.

set -euo pipefail

SRV_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

WITH_SECRETS=1
FORCE_SECRETS=0
args=()
for arg in "$@"; do
    case "$arg" in
        --no-secrets)   WITH_SECRETS=0 ;;
        --with-secrets) FORCE_SECRETS=1 ;;
        *)            args+=("$arg") ;;
    esac
done
set -- "${args[@]+"${args[@]}"}"

OUT_ARG="${1:-$HOME/server.zip}"
OUT="$(cd "$(dirname "$OUT_ARG")" && pwd)/$(basename "$OUT_ARG")"

# ---------------------------------------------------------------------------
# Refuse to ship a credential
# ---------------------------------------------------------------------------
# Nothing matching these should ever be in here — .gitignore blocks them — so
# finding one means something went wrong, and the right response is to stop
# rather than to copy a token onto another machine.
# secrets/secrets.enc is deliberately excluded from this list: it is the
# one credential file meant to travel, and it travels encrypted. Its plaintext
# counterpart is not.
LEAKS=$(cd "$SRV_DIR" && find . -path ./.git -prune -o \( \
    -name '.secrets*' -o -name 'secrets.env' -o -name 'secrets.zsh' -o -name 'rclone.conf' \
    -o -name '.git-credentials' -o -name 'auth.json' -o -name '.claude.json' \
    -o -name 'id_rsa*' -o -name 'id_ed25519*' -o -name '*.pem' -o -name '*.key' \
    -o -path './secrets/*.txt' \) -print 2>/dev/null)
if [[ -n "$LEAKS" ]]; then
    echo "refusing to build — secret-looking files in the bundle:" >&2
    echo "$LEAKS" >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# Warn if this copy has been pruned
# ---------------------------------------------------------------------------
missing=()
for profile in della tiger stellar adroit ionic neuronic princeton macos generic; do
    [[ -f "$SRV_DIR/hosts/$profile.sh" ]] || missing+=("$profile")
done
if (( ${#missing[@]} )); then
    echo "warning: this copy has been pruned — missing host profiles: ${missing[*]}" >&2
    echo "         the bundle will not be able to configure those machines." >&2
fi

# ---------------------------------------------------------------------------
# Say plainly what is about to be shipped
# ---------------------------------------------------------------------------
# A blob locked with a passphrase its own check called weak does not go into
# a zip that is going on the web. That decision was already made and recorded
# at lock time; this just honours it, rather than asking again at the one
# moment it is easiest to click through.
if (( WITH_SECRETS )) && [[ -r "$SRV_DIR/secrets/secrets.enc" ]] &&
   grep -q '^# strength: weak' "$SRV_DIR/secrets/secrets.enc" && (( ! FORCE_SECRETS )); then
    WITH_SECRETS=0
    cat >&2 <<'WEAK'
note: secrets/secrets.enc is locked with a passphrase marked weak, so it is
  being left OUT of this bundle. That is the right call if the zip goes on a
  public URL — a weak passphrase there is worth about an hour of rented GPUs.

  Copy it to a new machine by hand instead:
    scp ~/server/secrets/secrets.enc <host>:~/server/secrets/

  Include it anyway with:  ./make-bundle.sh --with-secrets

WEAK
fi

if (( WITH_SECRETS )) && [[ -r "$SRV_DIR/secrets/secrets.enc" ]]; then
    cat >&2 <<'WARN'
note: this bundle contains secrets/secrets.enc — your credentials.

  They are encrypted, but the ciphertext is only as strong as the passphrase:
  anyone who can fetch the zip can attack it offline, forever, on any hardware
  they like. Publishing it at a public URL is fine with a generated or 5-word
  passphrase, and not fine with a memorable one.

  Leave it out of a published bundle with:  ./make-bundle.sh --no-secrets

WARN
fi

rm -f "$OUT"
# .srv-state records that setup already ran *on this machine*. It is
# gitignored, but this builds the zip from the directory rather than from the
# git index, so it has to be named here too — shipping it would make a
# genuinely fresh machine skip its first prune.
EXCLUDES=('*/.git/*' '*/.git' '*.zip' '*/.DS_Store' '*/.srv-state' '*/.server-backup/*')
# secrets/ is an allowlist, not a blocklist: zip walks the working tree, not
# the git index, so a gitignored scratch file there (a passphrase note, say)
# would otherwise ride along. Only README.md and — when wanted — the encrypted
# blob itself are shipped; every other name found under secrets/ is excluded.
for f in "$SRV_DIR"/secrets/* "$SRV_DIR"/secrets/.[!.]* "$SRV_DIR"/secrets/..?*; do
    [[ -e "$f" ]] || continue
    case "$(basename "$f")" in
        README.md)   ;;
        secrets.enc) (( WITH_SECRETS )) || EXCLUDES+=('*/secrets/secrets.enc') ;;
        *)           EXCLUDES+=("*/secrets/$(basename "$f")" "*/secrets/$(basename "$f")/*")
                     echo "note: leaving secrets/$(basename "$f") out of the bundle" >&2 ;;
    esac
done

(cd "$(dirname "$SRV_DIR")" && zip -qr "$OUT" "$(basename "$SRV_DIR")" \
    -x "${EXCLUDES[@]}")

# The web bootstrap goes next to the zip, so the whole install is one command
# rather than three. $SRV_SITE_URL bakes in the real address; without it the
# placeholder stays and the script still works via $SERVER_ZIP_URL.
INSTALLER="$(dirname "$OUT")/install.sh"
URL_BASE="${SRV_SITE_URL:-https://example.com}"
URL_BASE="${URL_BASE%/}"
sed "s|__URL_BASE__|$URL_BASE|g" "$SRV_DIR/web/install.sh.template" > "$INSTALLER"
chmod +x "$INSTALLER"

# BSD du has no --apparent-size; try it, then fall back.
# BSD du also right-justifies the size with leading spaces, so cut on the
# tab and strip blanks rather than splitting on whitespace.
SIZE="$( (du -h --apparent-size "$OUT" 2>/dev/null || du -h "$OUT") | cut -f1 | tr -d ' ')"
printf 'built %s (%s)\n' "$OUT" "$SIZE"
printf 'built %s\n' "$INSTALLER"

if [[ "$URL_BASE" == "https://example.com" ]]; then
    cat <<'NEXT'

Set your site once so the installer carries the real address:

  export SRV_SITE_URL=https://your-site/path      # add it to ~/.zshrc.local
  ./make-bundle.sh

NEXT
fi

cat <<NEXT
Upload BOTH files to $URL_BASE/, then on a new machine:

  curl -fsSL $URL_BASE/install.sh | bash

Or without the website:

  scp $(basename "$OUT") <host>:~/
  ssh <host> -t 'unzip -q server.zip && ./server/setup.sh'
NEXT
