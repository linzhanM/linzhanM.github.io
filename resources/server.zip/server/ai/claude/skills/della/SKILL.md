---
name: della
description: Princeton Della HPC cluster essentials — connecting, head nodes, hardware, storage/quotas (/home, /scratch/gpfs, /projects), environment modules, and helper tools (checkquota, snodes, jobstats). Use when working on Della (della*.princeton.edu hosts), asking about cluster storage, quotas, modules, GPUs/nodes available, or how to connect. For submitting/monitoring Slurm jobs, see the della-slurm skill.
---

# Della cluster (Princeton Research Computing)

Facts below verified live on `della9.princeton.edu` (2026-08-25). Official docs: https://researchcomputing.princeton.edu/systems/della

## Connecting

- `ssh <netid>@della.princeton.edu` — lands on a shared head node (e.g. `della9`). Off-campus requires the Princeton VPN (GlobalProtect) or first hopping through `tigressgateway.princeton.edu`.
- Web portal (no VPN needed): https://mydella.princeton.edu — Open OnDemand with Jupyter, MATLAB, RStudio, remote desktop, file browser.
- Special head nodes (same filesystems):
  - `della-gpu` — general use with GPUs; use it to compile/test GPU code (**the main head nodes have no GPU** — `nvidia-smi` fails there).
  - `della-vis1`, `della-vis2` — data visualization.
  - `della-milan` — AMD GPU nodes; `della-grace` — NVIDIA Grace-Hopper (GH200, aarch64).
  - Various group-owned nodes (`della-pli`, `della-cryoem`, `della-feynman`, …) are private.
- OS: RHEL 9.8, x86_64 (Grace nodes are ARM). Scheduler: Slurm 25.11.

## Storage

| Path | What | Quota | Backed up | Use for |
|---|---|---|---|---|
| `/home/<netid>` | GPFS home | 50 GB, 2M files | yes | source code, envs, small software |
| `/scratch/gpfs/<GROUP>/` | 14 PB GPFS scratch fileset | group-level (e.g. ARORA: 210 TB, 100M files) | **NO** | job I/O, datasets, checkpoints |
| `/projects/<GROUP>` | long-term group storage | per-group | yes | archival results, shared group data |
| `/tigress` | legacy storage (being replaced by /projects) | — | yes | legacy data |
| node-local NVMe / `/tmp` | on nodes with `nvme` feature | — | no | fast per-job local scratch |

- This user's scratch lives under the group fileset: `/scratch/gpfs/ARORA/ss3419` (there is no personal `/scratch/gpfs/<netid>` for this account).
- `checkquota` — show usage/quotas for home and scratch. Quota increases: https://forms.rc.princeton.edu/quota
- Never run heavy I/O against `/home`; run jobs from `/scratch/gpfs`. Scratch is not backed up — copy irreplaceable results to `/projects`.

## Hardware overview (general-access)

- **CPU nodes** (default `cpu` partition, 166 nodes): mostly Intel Cascade Lake 32-core / 190 GB (`della-r3c*`), plus Ice Lake and large-memory nodes (`della-h12n*`: 96 cores, 6.1 TB RAM, feature `memory`).
- **GPU nodes** (`gpu` partition, 89 nodes):
  - 59 × 4× A100 80GB (48-core Ice Lake, 1 TB RAM, PCIe)
  - 20 × 2× A100 80GB (128-core, 768 GB)
  - 10 × A100 MIG `3g.40gb` slices (8 per node)
- **`mig` partition**: 2 nodes × 28 `1g.10gb` MIG slices — for small/single-GPU-slice jobs.
- **`grace` partition**: GH200 Grace-Hopper nodes (ARM CPUs; compile on `della-grace`).
- **`rtx6000` partition**: 1 node with 8× RTX Pro 6000.
- **PLI H100 nodes** (`pli*` partitions): 42 nodes × 8× H100 (96-core, 1 TB) — restricted to Princeton Language & Intelligence users. 18 nodes × 8× H200 (1.5 TB) also exist, restricted.
- Node features for `--constraint`: `cascade`, `icelake`, `sapphire`, `rome`, `genoa`, `amd`, `intel`, `a100`, `h100`, `h200`, `gpu80` (80GB GPUs), `nvme`, `memory` (large-mem), `rh9`.
- Inspect nodes: `snodes` (per-node table), `shownodes`.

## Software / modules

- Environment modules: `module avail`, `module load <name>`, `module purge`.
- Notable: `anaconda3/2026.7` (latest), `cudatoolkit/11.8–13.3`, `intel/2024.2` + `intel-mpi`, `openmpi/gcc/4.1.8` (incl. CUDA-aware builds), `gcc-toolset/14`, `julia/1.12.1`, `matlab/R2025b`, fftw/hdf5/netcdf built per compiler+MPI.
- Python: `module load anaconda3/2026.7` then `conda create`/`pip install --user`. Keep conda envs in `/home` (small) or scratch.
- GPU code: compile on `della-gpu` (or inside a GPU job) — head nodes lack GPUs/drivers.

## Etiquette

- Head nodes are for editing, compiling, light file ops only — no long computations; use `salloc` or the `gputest`/test QOS for testing (see della-slurm skill).
- Purge policies apply to scratch; check announcements before relying on old files.
