---
name: della-slurm
description: Submitting and monitoring Slurm jobs on Princeton's Della cluster — partitions (cpu, gpu, mig, grace, pli), automatic QOS assignment by walltime, per-user GPU/CPU limits, sbatch/salloc templates, and job monitoring (jobstats, squeue). Use whenever writing sbatch scripts, choosing partitions/QOS/GRES, requesting GPUs, debugging pending jobs, or checking job efficiency on Della.
---

# Slurm on Della

Verified live on Della (Slurm 25.11, 2026-08-25). QOS thresholds read from the cluster's own `job_submit.lua`.

## Partitions (general access)

| Partition | Nodes | Hardware | MaxTime |
|---|---|---|---|
| `cpu` (default) | 166 | Cascade/Ice Lake 32–96 cores, 190 GB–6.1 TB | 15 days (QOS-limited, see below) |
| `gpu` | 89 | 4×A100-80GB (48c/1TB), 2×A100-80GB (128c/768GB), A100 `3g.40gb` MIG | 15 days (QOS-limited) |
| `mig` | 2 | 28× `1g.10gb` A100 slices per node — small GPU jobs | 15 days |
| `grace` | 2 | GH200 Grace-Hopper (ARM) | 15 days |
| `rtx6000` | 1 | 8× RTX Pro 6000 | 15 days |
| `gputest` | 112 | A100 pool for short tests | — |
| `pli`, `pli-c`, `pli-p`, `pli-lc` | 38–42 | 8×H100 nodes (96c, 1TB) — PLI-restricted | 15d / 3d (`-c`,`-lc`) |

Do not set `--qos` manually for normal work — a submit plugin assigns it from your `--time`.

## QOS auto-assignment and limits

**CPU jobs** (thresholds from job_submit.lua: test ≤60 min, short ≤24 h, medium ≤72 h, else vlong; jobs longer than ~6 days need special arrangement):

| QOS | Walltime | Per-user limits |
|---|---|---|
| `test` | ≤ 1 h | 2 running jobs (highest priority) |
| `short` | ≤ 24 h | 1400 CPU-cores |
| `medium` | ≤ 72 h | 400 cores, 200 jobs |
| `vlong` | > 72 h (≈ ≤6 days) | 325 cores, 60 jobs |

**GPU jobs** (assigned when `--gres=gpu:` is requested):

| QOS | Walltime | Per-user limits |
|---|---|---|
| `gpu-test` | short tests | 3 running / 25 queued |
| `gpu-short` | ≤ 1 day | 44 GPUs |
| `gpu-medium` | ≤ 3 days | 20 GPUs, 24 nodes (160 GPUs across all users) |
| `gpu-long` | ≤ 6 days | 16 GPUs, 10 jobs |

Shorter `--time` ⇒ higher priority and easier backfill. Request accurate walltimes.

## Templates

CPU batch job:
```bash
#!/bin/bash
#SBATCH --job-name=myjob
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem-per-cpu=4G          # or --mem=32G per node
#SBATCH --time=24:00:00
#SBATCH --mail-type=fail          # optional; mail-user defaults to <netid>@princeton.edu
module purge
module load anaconda3/2026.7
srun python myscript.py
```

GPU batch job (A100):
```bash
#SBATCH --partition=gpu           # usually optional; gres request routes to GPU nodes
#SBATCH --gres=gpu:1              # or gpu:a100:2 ; add --constraint=gpu80 for 80GB A100s
#SBATCH --cpus-per-task=8
#SBATCH --time=23:59:00           # stays in gpu-short
module load cudatoolkit/12.9
```
- Small GPU needs → `--partition=mig --gres=gpu:1` (a `1g.10gb` slice, cheap and fast to schedule).
- Multi-node MPI: `module load openmpi/gcc/4.1.8` (or intel-mpi) and use `srun`.

Interactive:
```bash
salloc --nodes=1 --ntasks=1 --cpus-per-task=4 --mem=16G --time=01:00:00           # CPU (test QOS)
salloc --gres=gpu:1 --time=01:00:00 --cpus-per-task=8 --mem=32G                   # GPU
```

## Monitoring & debugging

- `squeue -u $USER` — state; `squeue --start -j <id>` — estimated start.
- `jobstats <jobid>` — Princeton's efficiency report (CPU/GPU/memory utilization); check it after runs and right-size requests.
- `snodes` / `shownodes` — per-node availability, features, GPU types.
- `scontrol show job <id>`, `sacct -j <id>`, `scancel <id>`.
- `sshare -u $USER` — fairshare; pending `Priority`/`Resources` is normal, `QOSMaxGRESPerUser`-style reasons mean you hit the per-user caps above.
- Run jobs from `/scratch/gpfs/<GROUP>/<netid>` (e.g. `/scratch/gpfs/ARORA/ss3419`), never heavy I/O in `/home` (see della skill).

## Gotchas

- Head nodes (`della9`, etc.) have no GPUs — GPU code must be compiled on `della-gpu` or in a job.
- `grace` partition is ARM (aarch64): x86 binaries/conda envs won't run; build on `della-grace`.
- Default memory per CPU is small — set `--mem` or `--mem-per-cpu` explicitly.
- `--constraint` feature tags: `cascade`, `icelake`, `amd`, `a100`, `gpu80`, `nvme`, `memory` (6TB nodes).
