#!/usr/bin/env bash
# tools/claude.sh — Claude Code.
#
# The native installer, not npm: it drops a self-contained binary in
# ~/.local/bin/claude with its versions under ~/.local/share/claude, so no
# node runtime is needed and nothing depends on a cluster module.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

if have claude; then
    say "ok   claude $(claude --version 2>/dev/null | head -1) ($(command -v claude))"
elif [ "$SRV_DRY_RUN" = 1 ]; then
    say "would install Claude Code from https://claude.ai/install.sh"
elif ! online; then
    warn "offline — skipping Claude Code"
elif install_script "Claude Code" https://claude.ai/install.sh bash; then
    say "installed claude -> $HOME/.local/bin/claude"
else
    warn "see https://docs.claude.com/claude-code"
fi

# settings.json is seeded rather than copied over: Claude Code rewrites it
# itself (enabling a plugin, recording a marketplace), and those edits are
# machine-local. The skills are hand-written and belong to this bundle, so
# they are copied and kept in step. Marketplace skills already in
# ~/.claude/skills are untouched — deploy_dir works entry by entry.
#
# The skills are Princeton cluster knowledge, and setup.sh prunes them from
# the bundle on any other machine — after this script has run, so the copy
# is gated here too, or a laptop would get them anyway. Run on its own, this
# script has no setup.sh to have detected the machine, so it detects it.
step "Claude Code configuration"
copy_once claude/settings.json .claude/settings.json
[ -n "${SRV_CLASS:-}" ] || . "$SRV_DIR/lib/detect.sh"
if [ "$SRV_CLASS" = princeton ]; then
    deploy_dir claude/skills .claude/skills
else
    say "skip .claude/skills (Princeton cluster skills — not a Princeton machine)"
fi

if [ ! -s "$HOME/.claude.json" ] && [ "$SRV_DRY_RUN" != 1 ]; then
    say "note: run \`claude\` once to sign in (this machine has no credentials yet)"
fi
