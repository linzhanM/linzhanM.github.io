#!/usr/bin/env bash
# tools/cli.sh — the small fast CLI tools, installed user-local.
#
# These matter more on a cluster than on a laptop: there is no sudo, the
# system binaries are whatever RHEL shipped years ago, and the filesystem is a
# slow shared one where `grep -r` across a source tree is genuinely painful.
# Each of these is a single static binary that drops into ~/.local/bin, which
# shell/env.sh already has on PATH.
#
#   fzf   fuzzy finder — Ctrl-R over history, Ctrl-T over files
#   rg    ripgrep, the fast recursive grep
#   fd    a sane `find`
#   bat   `cat` with syntax highlighting and paging
#   eza   `ls` with a tree mode and git status
#
# Skipped, on purpose: zoxide, because oh-my-zsh's `z` plugin is already
# loaded in shell/zshrc and running both means two directory databases
# disagreeing about where you have been.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

BIN="$HOME/.local/bin"

case "$(uname -m)" in
    x86_64)        ARCH=x86_64;  FZF_ARCH=amd64 ;;
    aarch64|arm64) ARCH=aarch64; FZF_ARCH=arm64 ;;
    *) say "no prebuilt binaries for $(uname -m) — skipping"; exit 0 ;;
esac
if [ "${SRV_OS:-linux}" = macos ]; then
    say "on macOS these come from Homebrew — skipping"
    say "  brew install fzf ripgrep fd bat eza"
    exit 0
fi

# latest_asset <owner/repo> <extended-regex matching the asset name>
#
# Resolved through the API rather than the /releases/latest/download/ path,
# because every one of these embeds its version in the filename. $GITHUB_TOKEN
# is used when set: unauthenticated GitHub allows 60 calls an hour per IP, and
# on a cluster login node that IP is shared with everyone else.
latest_asset() {
    local repo="$1" pattern="$2" auth=()
    [ -n "${GITHUB_TOKEN:-}" ] && auth=(-H "Authorization: Bearer $GITHUB_TOKEN")
    curl -fsSL "${auth[@]}" "https://api.github.com/repos/$repo/releases/latest" 2>/dev/null |
        grep -oE '"browser_download_url": *"[^"]+"' |
        sed -E 's/.*"(https[^"]+)"/\1/' |
        grep -E "$pattern" | head -1
}

# install_tool <command> <owner/repo> <asset regex> <basename inside archive>
install_tool() {
    local cmd="$1" repo="$2" pattern="$3" member="$4" url tmp

    if have "$cmd"; then
        say "ok   $cmd ($(command -v "$cmd"))"
        return 0
    fi
    if [ "$SRV_DRY_RUN" = 1 ]; then
        say "would install $cmd from $repo"
        return 0
    fi

    url="$(latest_asset "$repo" "$pattern")" || true
    if [ -z "${url:-}" ]; then
        warn "could not find a $cmd release asset for $ARCH (rate-limited, or offline)"
        return 0
    fi

    tmp="$(mktemp -d "${TMPDIR:-/tmp}/srvcli.XXXXXX")"
    if fetch "$url" | tar -xz -C "$tmp" 2>/dev/null; then
        local found
        found="$(find "$tmp" -type f -name "$member" -perm -u+x | head -1)"
        if [ -n "$found" ]; then
            mkdir -p "$BIN" && install -m 755 "$found" "$BIN/$cmd"
            say "installed $cmd -> $BIN/$cmd"
        else
            warn "$member not found inside the $cmd archive"
        fi
    else
        warn "could not unpack $cmd from $url"
    fi
    rm -rf "$tmp"
}

online || { warn "offline — skipping the CLI tools"; exit 0; }

install_tool fzf junegunn/fzf      "linux_${FZF_ARCH}\.tar\.gz$"                fzf
install_tool rg  BurntSushi/ripgrep "${ARCH}-unknown-linux-musl\.tar\.gz$"      rg
install_tool fd  sharkdp/fd         "${ARCH}-unknown-linux-musl\.tar\.gz$"      fd
install_tool bat sharkdp/bat        "${ARCH}-unknown-linux-musl\.tar\.gz$"      bat
install_tool eza eza-community/eza  "${ARCH}-unknown-linux-musl\.tar\.gz$"      eza

have fzf && say "note: Ctrl-R searches history, Ctrl-T inserts a file path"
true
