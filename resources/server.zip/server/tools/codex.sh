#!/usr/bin/env bash
# tools/codex.sh — OpenAI Codex CLI.
#
# The standalone installer, not npm: it unpacks a musl-static binary under
# ~/.codex/packages/ and links ~/.local/bin/codex at it, so it runs on the
# clusters' older glibc without any runtime to install.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

if have codex; then
    say "ok   codex $(codex --version 2>/dev/null | head -1) ($(command -v codex))"
elif [ "$SRV_DRY_RUN" = 1 ]; then
    say "would install Codex from https://chatgpt.com/codex/install.sh"
elif ! online; then
    warn "offline — skipping Codex"
elif fetch https://chatgpt.com/codex/install.sh | bash >"${TMPDIR:-/tmp}/srv-install-$$.log" 2>&1; then
    rm -f "${TMPDIR:-/tmp}/srv-install-$$.log"
    say "installed codex -> $HOME/.local/bin/codex"
else
    warn "Codex install failed — see https://developers.openai.com/codex/cli"
    tail -n 5 "${TMPDIR:-/tmp}/srv-install-$$.log" 2>/dev/null | sed 's/^/     /' >&2
    rm -f "${TMPDIR:-/tmp}/srv-install-$$.log"
fi

# Seeded, not symlinked: codex appends a [projects."<path>"] trust entry to
# this file as you use it, and those paths are machine-local.
step "Codex configuration"
copy_once ai/codex/config.toml .codex/config.toml

if [ ! -e "$HOME/.codex/auth.json" ] && [ "$SRV_DRY_RUN" != 1 ]; then
    say "note: run \`codex login\` once to sign in (this machine has no credentials yet)"
fi
