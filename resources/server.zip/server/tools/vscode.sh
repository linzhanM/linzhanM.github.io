#!/usr/bin/env bash
# tools/vscode.sh — VS Code Remote settings for this machine.
#
# Only one thing matters here, and it is worth the file: both Python
# extensions default to activating the selected interpreter by TYPING
# "conda activate <env>" into every new integrated terminal. That races with
# the shell prompt — the injected text lands in the middle of whatever you
# were typing, and your history fills with lines like "ls  conda activate ml".
# Turning it off loses nothing, because shell/env.sh already puts conda on
# PATH and defines the shell function.
#
# These are Machine settings, so they apply to every workspace opened on this
# host, and a workspace .vscode/settings.json can still override them.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

DEST="$HOME/.vscode-server/data/Machine/settings.json"

if [ ! -d "$HOME/.vscode-server" ]; then
    say "no ~/.vscode-server here — skipping (nothing connects to this box yet)"
    exit 0
fi
if [ "$SRV_DRY_RUN" = 1 ]; then
    say "would merge vscode/settings.json into $DEST"
    exit 0
fi

# Merged rather than copied: VS Code and its extensions write their own keys
# into this file, and clobbering them would undo unrelated settings.
mkdir -p "$(dirname "$DEST")"
python3 - "$SRV_DIR/vscode/settings.json" "$DEST" <<'PY'
import json, re, sys, pathlib, shutil

src, dst = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])

def load(path):
    if not path.exists():
        return {}
    text = re.sub(r'^\s*//.*$', '', path.read_text(), flags=re.M)  # jsonc comments
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        print(f"   ! {path} is not valid JSON — leaving it alone", file=sys.stderr)
        sys.exit(1)

wanted, current = load(src), load(dst)
changed = {k: v for k, v in wanted.items() if current.get(k) != v}

if not changed:
    print("   ok   VS Code settings already correct")
    sys.exit(0)

if dst.exists():
    shutil.copy(dst, str(dst) + ".bak")
current.update(wanted)
dst.write_text(json.dumps(current, indent=2) + "\n")
for k, v in changed.items():
    print(f"   set  {k} = {json.dumps(v)}")
PY

say "reload the VS Code window for this to take effect (Cmd/Ctrl-Shift-P, 'Reload Window')"
