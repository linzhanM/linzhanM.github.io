#!/usr/bin/env bash
# tools/claude-code.sh — Claude Code.
#
# The native installer, not npm: it drops a self-contained binary in
# ~/.local/bin/claude with its versions under ~/.local/share/claude, so no
# node runtime is needed and nothing depends on a cluster module.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

if have claude; then
    say "ok   claude $(claude --version 2>/dev/null | head -1) ($(command -v claude))"
elif [ "$SRV_DRY_RUN" = 1 ]; then
    say "would install Claude Code from https://claude.ai/install.sh"
elif ! online; then
    warn "offline — skipping Claude Code"
elif fetch https://claude.ai/install.sh | bash >"${TMPDIR:-/tmp}/srv-install-$$.log" 2>&1; then
    rm -f "${TMPDIR:-/tmp}/srv-install-$$.log"
    say "installed claude -> $HOME/.local/bin/claude"
else
    warn "Claude Code install failed — see https://docs.claude.com/claude-code"
    tail -n 5 "${TMPDIR:-/tmp}/srv-install-$$.log" 2>/dev/null | sed 's/^/     /' >&2
    rm -f "${TMPDIR:-/tmp}/srv-install-$$.log"
fi

# settings.json is seeded rather than copied over: Claude Code rewrites it
# itself (enabling a plugin, recording a marketplace), and those edits are
# machine-local. The skills are hand-written and belong to this bundle, so
# they are copied and kept in step. Marketplace skills already in
# ~/.claude/skills are untouched — deploy_dir works entry by entry.
step "Claude Code configuration"
copy_once  ai/claude/settings.json .claude/settings.json
deploy_dir ai/claude/skills        .claude/skills

if [ ! -s "$HOME/.claude.json" ] && [ "$SRV_DRY_RUN" != 1 ]; then
    say "note: run \`claude\` once to sign in (this machine has no credentials yet)"
fi
