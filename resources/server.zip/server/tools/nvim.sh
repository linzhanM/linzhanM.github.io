#!/usr/bin/env bash
# tools/nvim.sh — Neovim plus the kickstart.nvim config.
#
# The cluster nvim is either absent or ancient, so a release tarball is
# unpacked into ~/software and the host profiles put it on PATH. The config is
# a clone rather than vendored: kickstart keeps itself up to date through its
# own git remote.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/common.sh"

NVIM_VERSION="${NVIM_VERSION:-stable}"

nvim_new_enough() {
    have nvim || return 1
    # kickstart.nvim needs 0.9+; anything older is worse than not having it.
    nvim --version 2>/dev/null | head -1 |
        awk '{ split($2, v, /[v.]/); exit !(v[2] > 0 || v[3] >= 9) }'
}

if nvim_new_enough; then
    say "ok   $(nvim --version | head -1) ($(command -v nvim))"
elif [ "$SRV_DRY_RUN" = 1 ]; then
    say "would download Neovim $NVIM_VERSION into ~/software"
elif [ "${SRV_OS:-linux}" = macos ]; then
    if have brew; then
        run brew install neovim
    else
        warn "no Homebrew — install Neovim with: brew install neovim"
    fi
elif ! online; then
    warn "offline — skipping Neovim"
else
    case "$(uname -m)" in
        x86_64)          asset=nvim-linux-x86_64 ;;
        aarch64|arm64)   asset=nvim-linux-arm64  ;;
        *) warn "no Neovim build for $(uname -m) — skipping"; exit 0 ;;
    esac

    mkdir -p "$HOME/software"
    url="https://github.com/neovim/neovim/releases/download/$NVIM_VERSION/$asset.tar.gz"
    if fetch "$url" | tar -xz -C "$HOME/software" 2>/dev/null; then
        # The host profiles put ~/software/nvim-linux64/bin on PATH; keep that
        # one name whatever the release tarball happens to be called.
        rm -rf "$HOME/software/nvim-linux64"
        mv "$HOME/software/$asset" "$HOME/software/nvim-linux64"
        say "installed $("$HOME/software/nvim-linux64/bin/nvim" --version | head -1)"
    else
        warn "could not download $url — skipping Neovim"
    fi
fi

clone_if_missing https://github.com/nvim-lua/kickstart.nvim.git "$HOME/.config/nvim" || true
