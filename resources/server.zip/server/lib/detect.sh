# lib/detect.sh — work out what kind of machine this is.
#
# Sets three variables and nothing else. Everything machine-specific in this
# bundle keys off them, so adding a server means adding one pattern here and
# one hosts/<name>.sh profile — no other file changes.
#
#   SRV_OS     linux | macos
#   SRV_HOST   della | ionic | tiger | stellar | adroit | neuronic
#              | princeton | macos | generic   -> selects hosts/<name>.sh
#   SRV_CLASS  princeton | generic        -> "is this a Princeton RC cluster?"
#
# SRV_CLASS is the coarse switch used for decisions that are the same across
# every Princeton machine (module system present, /scratch/gpfs exists, SLURM
# is worth configuring) without hard-coding a list of cluster names.
#
# POSIX sh: sourced by bash and by zsh, interactive and not.

# ---------------------------------------------------------------------------
# OS
# ---------------------------------------------------------------------------
if [ -z "${SRV_OS:-}" ]; then
    case "$(uname -s 2>/dev/null)" in
        Darwin) SRV_OS=macos ;;
        *)      SRV_OS=linux ;;
    esac
fi

# ---------------------------------------------------------------------------
# Host
# ---------------------------------------------------------------------------
# Both forms are checked: `hostname -f` is the reliable one on the clusters,
# but it is slow-to-failing on a laptop that is off the network, so the short
# name is the fallback rather than the other way round.
if [ -z "${SRV_HOST:-}" ]; then
    _srv_name=$(hostname -f 2>/dev/null || hostname 2>/dev/null || echo unknown)

    case "$_srv_name" in
        della*|*.della.*)       SRV_HOST=della    ;;
        tiger*|*.tiger.*)       SRV_HOST=tiger    ;;
        stellar*|*.stellar.*)   SRV_HOST=stellar  ;;
        adroit*|*.adroit.*)     SRV_HOST=adroit   ;;
        ionic*|*.ionic.*)       SRV_HOST=ionic    ;;
        neuronic*|*.neuronic.*) SRV_HOST=neuronic ;;
        *)
            if [ "$SRV_OS" = macos ]; then
                SRV_HOST=macos
            else
                SRV_HOST=generic
            fi
            ;;
    esac
fi

# ---------------------------------------------------------------------------
# Class
# ---------------------------------------------------------------------------
# Named clusters first; then two signatures that catch a Princeton machine
# this file has never heard of — the RC software tree, and the domain. A
# compute node inside a job answers to a bare nodename like `della-l04g1`,
# which the host patterns above already match, so this is only about the
# genuinely unknown ones.
if [ -z "${SRV_CLASS:-}" ]; then
    case "$SRV_HOST" in
        della|tiger|stellar|adroit|ionic|neuronic)
            SRV_CLASS=princeton ;;
        *)
            if [ -d /usr/licensed ] || [ -d /scratch/gpfs ]; then
                SRV_CLASS=princeton
            else
                case "${_srv_name:-}" in
                    *.princeton.edu) SRV_CLASS=princeton ;;
                    *)               SRV_CLASS=generic   ;;
                esac
            fi
            ;;
    esac
fi

# An unrecognised Princeton machine gets the shared RC profile rather than
# the bare generic one: the module system and /scratch/gpfs are there even if
# this file has never seen the hostname.
if [ "$SRV_CLASS" = princeton ] && [ "$SRV_HOST" = generic ]; then
    SRV_HOST=princeton
fi

unset _srv_name
export SRV_OS SRV_HOST SRV_CLASS
