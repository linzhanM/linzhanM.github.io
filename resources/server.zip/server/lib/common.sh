# lib/common.sh — helpers shared by setup.sh, secrets.sh and everything in tools/.
#
# Sourced, never executed. Defines the output helpers, the copy/backup logic
# and the guards that let setup.sh and every tools/*.sh script be re-run
# safely.

# Set by setup.sh from its flags; defaults let a tools/*.sh script be run
# on its own (`./tools/claude.sh`) without setup.sh around it.
: "${SRV_DIR:="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"}"
: "${SRV_DRY_RUN:=0}"
: "${SRV_BACKUP_DIR:="$HOME/.server-backup/$(date +%Y%m%d-%H%M%S)"}"


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
step() { printf '\n== %s\n' "$*"; }
say()  { printf '   %s\n' "$*"; }
warn() { printf '   ! %s\n' "$*" >&2; }

# run <cmd...> : execute, or just describe it under --dry-run
run() {
    if [ "$SRV_DRY_RUN" = 1 ]; then
        say "would: $*"
    else
        "$@"
    fi
}

have() { command -v "$1" >/dev/null 2>&1; }


# ---------------------------------------------------------------------------
# Backing up
# ---------------------------------------------------------------------------
# Nothing in this repo ever deletes a file the user put there: whatever is in
# the way is moved under ~/.server-backup/<timestamp>/ first.
backup() {
    local dst="$1" rel="${1#"$HOME"/}"
    [ -e "$dst" ] || [ -L "$dst" ] || return 0
    run mkdir -p "$SRV_BACKUP_DIR/$(dirname "$rel")"
    run mv "$dst" "$SRV_BACKUP_DIR/$rel"
    say "back $rel -> ~/.server-backup/${SRV_BACKUP_DIR##*/}/$rel"
}


# ---------------------------------------------------------------------------
# Deploying
# ---------------------------------------------------------------------------
# Files are COPIED out of the bundle into $HOME, never symlinked. That keeps
# $HOME self-contained: nothing breaks if this directory is moved, renamed or
# deleted, and a config still works inside a container or on a node that does
# not mount the same filesystem.
#
# The bundle is the source of truth, so a copy that has drifted is backed up
# and replaced. Push local edits the other way with `srvpull` before syncing.

# deploy <path relative to this bundle> <path relative to $HOME>
deploy() {
    local src="$SRV_DIR/$1" dst="$HOME/$2"

    if [ ! -e "$src" ]; then
        say "skip $2 (no $1 in this bundle)"
        return 0
    fi
    # Already identical: leave it alone rather than churn a backup on every
    # run. Skills and other bundled directories need the recursive compare.
    if [ ! -L "$dst" ]; then
        if [ -f "$src" ] && [ -f "$dst" ] && cmp -s "$src" "$dst"; then
            say "ok   $2"; return 0
        fi
        if [ -d "$src" ] && [ -d "$dst" ] && diff -rq "$src" "$dst" >/dev/null 2>&1; then
            say "ok   $2"; return 0
        fi
    fi

    backup "$dst"
    run mkdir -p "$(dirname "$dst")"
    run cp -R "$src" "$dst"
    say "copy $2"
}

# deploy_dir <dir relative to this bundle> <dir relative to $HOME>
#
# Per-entry rather than a whole-directory copy, so unrelated things already in
# the target (skills installed from a marketplace, say) are left alone.
deploy_dir() {
    local src="$SRV_DIR/$1" entry

    [ -d "$src" ] || { say "skip $2 (no $1 in this bundle)"; return 0; }
    run mkdir -p "$HOME/$2"
    for entry in "$src"/* "$src"/.[!.]* "$src"/..?*; do
        [ -e "$entry" ] || continue
        case "$(basename "$entry")" in .git|.DS_Store) continue ;; esac
        deploy "$1/$(basename "$entry")" "$2/$(basename "$entry")"
    done
}

# copy_once <path relative to this bundle> <path relative to $HOME>
#
# For files the tool itself rewrites — ~/.claude/settings.json gains entries
# when a plugin is enabled, ~/.codex/config.toml gains per-project trust. Those
# edits are machine-local and must not be clobbered on every sync, so these are
# seeded once and then left alone.
copy_once() {
    local src="$SRV_DIR/$1" dst="$HOME/$2"

    if [ ! -e "$src" ]; then
        say "skip $2 (no $1 in this bundle)"
        return 0
    fi
    if [ -e "$dst" ]; then
        say "keep $2 (already here — the bundle's version is $1)"
        return 0
    fi

    run mkdir -p "$(dirname "$dst")"
    run cp -R "$src" "$dst"
    say "seed $2"
}


# ---------------------------------------------------------------------------
# Fetching
# ---------------------------------------------------------------------------
# clone_if_missing <url> <dest> : shallow clone, tolerant of no network
clone_if_missing() {
    local url="$1" dest="$2" name top
    name="$(basename "$dest")"

    # A directory tree with no files in it (a failed clone's leftover parents,
    # or a `mkdir -p` scaffold) is in the way of the clone but might still be
    # the user's. It is moved to the backup dir like any other displaced file
    # — never deleted — and the move goes through `run`, so --dry-run only
    # describes it.
    if [ -d "$dest" ] && [ ! -d "$dest/.git" ] &&
       [ -z "$(find "$dest" -mindepth 1 ! -type d 2>/dev/null | head -n 1)" ]; then
        say "move $name aside (empty directory tree, not a clone)"
        backup "$dest"
        if [ "$SRV_DRY_RUN" = 1 ]; then
            say "would clone $url -> $dest"
            return 0
        fi
    fi

    if [ -d "$dest/.git" ]; then
        say "ok   $name"
        return 0
    elif [ -e "$dest" ]; then
        say "keep $name (exists but is not a git clone — left alone)"
        return 0
    elif [ "$SRV_DRY_RUN" = 1 ]; then
        say "would clone $url -> $dest"
        return 0
    fi

    # Remember the topmost directory the clone will have to create, so a
    # failure can remove exactly what it made and nothing that was there.
    top="$dest"
    while [ ! -e "$(dirname "$top")" ]; do top="$(dirname "$top")"; done

    if git clone --depth 1 "$url" "$dest" >/dev/null 2>&1; then
        say "clone $name"
    else
        # Everything under $top is the clone's; rmdir only ever removes empty
        # directories, and one call per directory (not `+`) so each parent is
        # already empty by the time -depth reaches it.
        [ -e "$top" ] && find "$top" -depth -type d -exec rmdir {} \; 2>/dev/null
        warn "could not clone $url (no network?) — rerun setup.sh when online"
        return 1
    fi
}

# install_script <label> <url> <interpreter...> : fetch a vendor install
# script and pipe it into <interpreter...> (bash, sh, `env X=1 sh`, ...).
# Output goes to a private temp log; on failure the last lines are shown.
# Safe under `set -euo pipefail`: nothing here can abort the caller, so the
# configuration steps that follow an install still run.
install_script() {
    local label="$1" url="$2" log rc=0
    shift 2
    log="$(mktemp "${TMPDIR:-/tmp}/srv-install.XXXXXX" 2>/dev/null)" || {
        warn "cannot create a temp file under ${TMPDIR:-/tmp}"; return 1; }
    if fetch "$url" | "$@" >"$log" 2>&1; then
        rc=0
    else
        rc=1
        warn "$label install failed:"
        if [ -s "$log" ]; then
            { tail -n 5 "$log" | sed 's/^/     /' >&2; } || true
        fi
    fi
    rm -f "$log"
    return $rc
}

# fetch <url> : write the URL's body to stdout, curl or wget, whichever exists
fetch() {
    if have curl; then
        curl -fsSL "$1"
    elif have wget; then
        wget -qO- "$1"
    else
        warn "neither curl nor wget is installed — cannot download $1"
        return 1
    fi
}

# online : cheap reachability check, so installers can skip instead of hanging
online() {
    if have curl; then
        curl -fsS --max-time 5 -o /dev/null https://github.com 2>/dev/null
    elif have wget; then
        wget -q --timeout=5 --spider https://github.com 2>/dev/null
    else
        return 1
    fi
}
