# lib/common.sh — helpers shared by setup.sh and everything in tools/.
#
# Sourced, never executed. Defines the output helpers, the copy/backup logic
# and the guards that let setup.sh and every tools/*.sh script be re-run
# safely.

# Set by setup.sh from its flags; defaults let a tools/*.sh script be run
# on its own (`./tools/claude-code.sh`) without setup.sh around it.
: "${SRV_DIR:="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"}"
: "${SRV_DRY_RUN:=0}"
: "${SRV_BACKUP_DIR:="$HOME/.server-backup/$(date +%Y%m%d-%H%M%S)"}"


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------
step() { printf '\n== %s\n' "$*"; }
say()  { printf '   %s\n' "$*"; }
warn() { printf '   ! %s\n' "$*" >&2; }

# run <cmd...> : execute, or just describe it under --dry-run
run() {
    if [ "$SRV_DRY_RUN" = 1 ]; then
        say "would: $*"
    else
        "$@"
    fi
}

have() { command -v "$1" >/dev/null 2>&1; }


# ---------------------------------------------------------------------------
# Backing up
# ---------------------------------------------------------------------------
# Nothing in this repo ever deletes a file the user put there: whatever is in
# the way is moved under ~/.server-backup/<timestamp>/ first.
backup() {
    local dst="$1" rel="${1#"$HOME"/}"
    [ -e "$dst" ] || [ -L "$dst" ] || return 0
    run mkdir -p "$SRV_BACKUP_DIR/$(dirname "$rel")"
    run mv "$dst" "$SRV_BACKUP_DIR/$rel"
    say "back $rel -> ~/.server-backup/${SRV_BACKUP_DIR##*/}/$rel"
}


# ---------------------------------------------------------------------------
# Deploying
# ---------------------------------------------------------------------------
# Files are COPIED out of the bundle into $HOME, never symlinked. That keeps
# $HOME self-contained: nothing breaks if this directory is moved, renamed or
# deleted, and a config still works inside a container or on a node that does
# not mount the same filesystem.
#
# The bundle is the source of truth, so a copy that has drifted is backed up
# and replaced. Push local edits the other way with `srvpull` before syncing.

# deploy <path relative to this bundle> <path relative to $HOME>
deploy() {
    local src="$SRV_DIR/$1" dst="$HOME/$2"

    if [ ! -e "$src" ]; then
        say "skip $2 (no $1 in this bundle)"
        return 0
    fi
    # Already identical: leave it alone rather than churn a backup on every
    # run. Skills and other bundled directories need the recursive compare.
    if [ ! -L "$dst" ]; then
        if [ -f "$src" ] && [ -f "$dst" ] && cmp -s "$src" "$dst"; then
            say "ok   $2"; return 0
        fi
        if [ -d "$src" ] && [ -d "$dst" ] && diff -rq "$src" "$dst" >/dev/null 2>&1; then
            say "ok   $2"; return 0
        fi
    fi

    backup "$dst"
    run mkdir -p "$(dirname "$dst")"
    run cp -R "$src" "$dst"
    say "copy $2"
}

# deploy_dir <dir relative to this bundle> <dir relative to $HOME>
#
# Per-entry rather than a whole-directory copy, so unrelated things already in
# the target (skills installed from a marketplace, say) are left alone.
deploy_dir() {
    local src="$SRV_DIR/$1" entry

    [ -d "$src" ] || { say "skip $2 (no $1 in this bundle)"; return 0; }
    run mkdir -p "$HOME/$2"
    for entry in "$src"/* "$src"/.[!.]* "$src"/..?*; do
        [ -e "$entry" ] || continue
        deploy "$1/$(basename "$entry")" "$2/$(basename "$entry")"
    done
}

# copy_once <path relative to this bundle> <path relative to $HOME>
#
# For files the tool itself rewrites — ~/.claude/settings.json gains entries
# when a plugin is enabled, ~/.codex/config.toml gains per-project trust. Those
# edits are machine-local and must not be clobbered on every sync, so these are
# seeded once and then left alone.
copy_once() {
    local src="$SRV_DIR/$1" dst="$HOME/$2"

    if [ ! -e "$src" ]; then
        say "skip $2 (no $1 in this bundle)"
        return 0
    fi
    if [ -e "$dst" ]; then
        say "keep $2 (already here — the bundle's version is $1)"
        return 0
    fi

    run mkdir -p "$(dirname "$dst")"
    run cp -R "$src" "$dst"
    say "seed $2"
}


# ---------------------------------------------------------------------------
# Fetching
# ---------------------------------------------------------------------------
# clone_if_missing <url> <dest> : shallow clone, tolerant of no network
clone_if_missing() {
    local url="$1" dest="$2" name
    name="$(basename "$dest")"

    # A failed clone leaves the parent directories it created behind (an
    # empty ~/.oh-my-zsh/custom/themes, say). A directory tree with no files
    # in it is therefore "absent", not "something of yours".
    if [ -d "$dest" ] && [ ! -d "$dest/.git" ] &&
       [ -z "$(find "$dest" -mindepth 1 ! -type d 2>/dev/null | head -n 1)" ]; then
        find "$dest" -depth -type d -exec rmdir {} + 2>/dev/null || true
    fi

    if [ -d "$dest/.git" ]; then
        say "ok   $name"
    elif [ -e "$dest" ]; then
        say "keep $name (exists but is not a git clone — left alone)"
    elif [ "$SRV_DRY_RUN" = 1 ]; then
        say "would clone $url -> $dest"
    elif git clone --depth 1 "$url" "$dest" >/dev/null 2>&1; then
        say "clone $name"
    else
        warn "could not clone $url (no network?) — rerun setup.sh when online"
        return 1
    fi
}

# fetch <url> : write the URL's body to stdout, curl or wget, whichever exists
fetch() {
    if have curl; then
        curl -fsSL "$1"
    elif have wget; then
        wget -qO- "$1"
    else
        warn "neither curl nor wget is installed — cannot download $1"
        return 1
    fi
}

# online : cheap reachability check, so installers can skip instead of hanging
online() {
    if have curl; then
        curl -fsS --max-time 5 -o /dev/null https://github.com 2>/dev/null
    elif have wget; then
        wget -q --timeout=5 --spider https://github.com 2>/dev/null
    else
        return 1
    fi
}
