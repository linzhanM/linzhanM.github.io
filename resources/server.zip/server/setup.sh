#!/usr/bin/env bash
# setup.sh — configure this machine from the bundle. The only entry point.
#
#   unzip -q server.zip && ./server/setup.sh
#
# Safe to run twice: it detects what this machine is, copies the configs that
# apply into $HOME (backing up anything it displaces), installs the tools that
# are missing, and deletes the parts of the bundle that this machine will
# never use.
#
# Options
#   --dry-run          print every action, change nothing
#   --config-only      copy configs, install nothing
#   --tools=a,b,c      run only these installers from tools/
#   --conda            install conda without asking
#   --no-conda         do not install conda and do not ask
#   --gdrive           configure the gdrive rclone remote without asking
#   --no-gdrive        do not configure it and do not ask
#   --keep-all         never prune; keep every host profile
#   --prune            prune even when the rules below would skip it
#   --secrets          unlock the bundled encrypted secrets without asking
#   --no-secrets       do not try to unlock the bundled encrypted secrets
#   --yes              accept every prompt (for unattended runs)
#   --here             configure from where the bundle is, do not move it

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="$HOME/server"

DRY_RUN=0 CONFIG_ONLY=0 PRUNE=1 PRUNE_FORCED=0 MOVE=1 ASSUME_YES=0
CONDA_CHOICE=ask
GDRIVE_CHOICE=ask
SECRETS_CHOICE=ask
TOOLS_REQUESTED=""

for arg in "$@"; do
    case "$arg" in
        --dry-run)     DRY_RUN=1 ;;
        --config-only) CONFIG_ONLY=1 ;;
        --tools=*)     TOOLS_REQUESTED="${arg#*=}" ;;
        --conda)       CONDA_CHOICE=yes ;;
        --no-conda)    CONDA_CHOICE=no ;;
        --gdrive)      GDRIVE_CHOICE=yes ;;
        --no-gdrive)   GDRIVE_CHOICE=no ;;
        --keep-all)    PRUNE=0 ;;
        --prune)       PRUNE=1; PRUNE_FORCED=1 ;;
        --no-secrets)  SECRETS_CHOICE=no ;;
        --secrets)     SECRETS_CHOICE=yes ;;
        --yes|-y)      ASSUME_YES=1 ;;
        --here)        MOVE=0 ;;
        # The comment block above, up to the first non-comment line.
        -h|--help)     sed -n '2,/^[^#]/{/^#/s/^# \{0,1\}//p;}' "$0"; exit 0 ;;
        *) echo "unknown option: $arg (try --help)" >&2; exit 2 ;;
    esac
done


# ---------------------------------------------------------------------------
# Move the bundle to ~/server
# ---------------------------------------------------------------------------
# Unzipping in $HOME already puts it there; unzipping anywhere else, or
# cloning under a different name, does not. Everything downstream — the
# $SRV_DIR in the shell configs, srvsync — expects the one path.
if (( MOVE )) && [[ "$SRC" != "$DEST" ]]; then
    if [[ -e "$DEST" ]]; then
        echo "$DEST already exists and is not this bundle." >&2
        echo "Move it aside, or re-run with --here to configure from $SRC." >&2
        exit 1
    fi
    if (( DRY_RUN )); then
        echo "would move $SRC -> $DEST"
    else
        mv "$SRC" "$DEST"
        exec "$DEST/setup.sh" "$@"          # re-exec from the new location
    fi
fi

export SRV_DIR="${SRC}"
(( MOVE )) && [[ -d "$DEST" ]] && export SRV_DIR="$DEST"
export SRV_DRY_RUN="$DRY_RUN"
export SRV_BACKUP_DIR="$HOME/.server-backup/$(date +%Y%m%d-%H%M%S)"

# shellcheck source=lib/common.sh
. "$SRV_DIR/lib/common.sh"

# ask <question> [default:y|n] : prompt, or fall back to the default when
# there is no terminal to prompt at (a piped install, CI, a provisioning run).
ask() {
    local question="$1" default="${2:-n}" reply
    if (( ASSUME_YES )); then return 0; fi
    if [[ ! -t 0 ]]; then
        say "no terminal — assuming '$default' for: $question"
        [[ "$default" == y ]]
        return
    fi
    read -r -p "   $question [$( [[ $default == y ]] && echo 'Y/n' || echo 'y/N' )] " reply
    reply="${reply:-$default}"
    [[ "$reply" =~ ^[Yy] ]]
}


# ---------------------------------------------------------------------------
step "What this machine is"
# ---------------------------------------------------------------------------
# lib/detect.sh is the single source of truth; nothing below re-derives it.
# shellcheck source=lib/detect.sh
. "$SRV_DIR/lib/detect.sh"

HAS_SLURM=0; have sbatch && HAS_SLURM=1
HAS_MODULES=0; [[ -d /etc/modulefiles || -d /usr/share/Modules || -n "${MODULEPATH:-}" ]] && HAS_MODULES=1

say "hostname : $(hostname -f 2>/dev/null || hostname)"
say "profile  : hosts/$SRV_HOST.sh"
say "class    : $SRV_CLASS on $SRV_OS"
say "slurm    : $( ((HAS_SLURM)) && echo yes || echo no )   modules: $( ((HAS_MODULES)) && echo yes || echo no )"

if [[ ! -r "$SRV_DIR/hosts/$SRV_HOST.sh" ]]; then
    warn "no hosts/$SRV_HOST.sh — falling back to hosts/generic.sh"
    warn "add a profile for this machine if you will use it regularly"
fi


# ---------------------------------------------------------------------------
step "Shell configuration"
# ---------------------------------------------------------------------------
# Copied, not symlinked: $HOME stays self-contained, so nothing breaks if this
# directory is later moved or deleted. `srvpull` copies edits back.
deploy shell/zshrc          .zshrc
deploy shell/bashrc         .bashrc
deploy shell/bash_profile   .bash_profile
deploy shell/p10k.zsh       .p10k.zsh
deploy git/gitconfig        .gitconfig
deploy git/ignore           .config/git/ignore
deploy tmux/tmux.conf       .tmux.conf
deploy tmux/tmux.conf.local .tmux.conf.local

# The runtime pieces the shell configs source at startup live in the bundle
# and are read from $SRV_DIR, so they are not copied — only the four files
# above are read by name from $HOME.


# ---------------------------------------------------------------------------
step "Secrets"
# ---------------------------------------------------------------------------
# ~/.secrets.env holds every API token. It reaches a new machine one of three
# ways, tried in this order: it is already here; the bundle carries an
# encrypted copy and you know the passphrase; or you copy it across yourself.
if [[ -e "$HOME/.secrets.env" ]]; then
    run chmod 600 "$HOME/.secrets.env"
    say "ok   ~/.secrets.env"

elif [[ -e "$HOME/.secrets.zsh" ]]; then
    run cp -p "$HOME/.secrets.zsh" "$HOME/.secrets.env"
    run chmod 600 "$HOME/.secrets.env"
    say "migrated ~/.secrets.zsh -> ~/.secrets.env (the old file is left in place)"

elif [[ -r "$SRV_DIR/secrets/secrets.enc" && "$SECRETS_CHOICE" != no ]]; then
    say "this bundle carries encrypted credentials"
    grep -E '^# (locked on|holds)' "$SRV_DIR/secrets/secrets.enc" | sed 's/^# /   /' || true
    if (( DRY_RUN )); then
        say "would prompt for the passphrase and unlock it"
    elif [[ "$SECRETS_CHOICE" == yes ]] || [[ -n "${SRV_SECRETS_PASSPHRASE:-}" ]] \
         || ask "Unlock it now?" y; then
        "$SRV_DIR/secrets.sh" unlock || {
            warn "continuing without tokens — unlock later with: srvunlock"
        }
    else
        say "skipped — unlock later with: srvunlock"
    fi

else
    run cp "$SRV_DIR/secrets/secrets.env.example" "$HOME/.secrets.env"
    run chmod 600 "$HOME/.secrets.env"
    say "created ~/.secrets.env from the template — put the real tokens in it, or:"
    say "  scp <other-host>:~/.secrets.env ~/.secrets.env && chmod 600 ~/.secrets.env"
fi


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
# Each installer is standalone and idempotent: it checks whether its tool is
# already here, installs it if not, and degrades to a warning when offline.
run_tool() {
    local name="$1"; shift
    local script="$SRV_DIR/tools/$name.sh"
    [[ -x "$script" ]] || { warn "no tools/$name.sh in this bundle"; return 0; }
    step "$name"
    "$script" "$@" || warn "tools/$name.sh did not finish cleanly — continuing"
}

if (( CONFIG_ONLY )); then
    step "Tools"
    say "skipped (--config-only)"
else
    if [[ -n "$TOOLS_REQUESTED" ]]; then
        IFS=, read -ra _tools <<< "$TOOLS_REQUESTED"
        for t in "${_tools[@]}"; do run_tool "$t"; done
    else
        run_tool zsh
        run_tool tmux
        run_tool nvim
        run_tool cli
        run_tool rclone
        run_tool uv
        run_tool claude
        run_tool codex
        run_tool vscode

        # ---------------------------------------------------------------
        # conda — always a question, never a default
        # ---------------------------------------------------------------
        # It is several GB, and most machines already have it: on the
        # Princeton clusters it comes from the anaconda3 module, elsewhere
        # there is often a system or Homebrew copy, and plenty of projects
        # use uv instead.
        step "conda"
        if have conda; then
            say "ok   conda already available ($(conda --version 2>/dev/null || echo 'shell function'))"
            if [[ "$CONDA_CHOICE" != no ]]; then
                "$SRV_DIR/tools/conda.sh" condarc || warn "tools/conda.sh did not finish cleanly — continuing"
            fi
        elif [[ "$CONDA_CHOICE" == no ]]; then
            say "skipped (--no-conda)"
        elif [[ "$CONDA_CHOICE" == yes ]]; then
            "$SRV_DIR/tools/conda.sh" install || true
        else
            say "conda is not installed here."
            (( HAS_MODULES )) && say "this machine has environment modules — 'module load anaconda3' may be all you need"
            if ask "Download and install conda (Miniforge, ~500 MB) now?" n; then
                "$SRV_DIR/tools/conda.sh" install || true
                CONDA_CHOICE=yes
            else
                say "skipped — run '$SRV_DIR/tools/conda.sh' later if you change your mind"
                CONDA_CHOICE=no
            fi
        fi

        # ---------------------------------------------------------------
        # Google Drive — a question, like conda
        # ---------------------------------------------------------------
        # The remote needs a Google consent in a browser (or a token pasted
        # from a laptop, on a cluster), so it is never set up unasked. A
        # remote restored from the encrypted bundle is already there, and
        # then there is nothing to ask.
        step "Google Drive (rclone)"
        if "$SRV_DIR/tools/rclone.sh" status; then
            say "ok   gdrive: remote is configured"
        elif [[ "$GDRIVE_CHOICE" == no ]]; then
            say "skipped (--no-gdrive)"
        elif [[ "$GDRIVE_CHOICE" == yes ]] || ask "Configure the gdrive rclone remote (Google Drive) now?" n; then
            "$SRV_DIR/tools/rclone.sh" gdrive || warn "tools/rclone.sh did not finish cleanly — continuing"
        else
            say "skipped — run '$SRV_DIR/tools/rclone.sh gdrive' later"
        fi
    fi
fi


# ---------------------------------------------------------------------------
step "Pruning what this machine will not use"
# ---------------------------------------------------------------------------
# The bundle ships every cluster profile and every helper because it has to
# work anywhere. Once it knows where it landed, the rest is dead weight and
# only makes the directory harder to read. Nothing here is unrecoverable: the
# full bundle is one `make-bundle.sh` away on any other machine.
PRUNED=()

drop() {
    local target="$SRV_DIR/$1" why="$2"
    [[ -e "$target" ]] || return 0
    if (( DRY_RUN )); then
        say "would drop $1 ($why)"
    else
        rm -rf "$target"
        say "drop $1 ($why)"
    fi
    PRUNED+=("$1")
}

# Pruning is a first-install action, not something to repeat on every run.
# Two rules keep it from doing damage later:
#
#   Already done here. srvsync re-runs this script, and there is nothing left
#   to prune the second time — but re-running would also delete any profile a
#   `git pull` had just brought back.
#
#   This bundle has a git remote. Then it is the shared copy that every other
#   machine pulls from, and the other clusters' profiles have to survive. A
#   local prune commit would also diverge from the remote and break the next
#   `git pull --ff-only`.
#
# --prune overrides both.
SRV_STATE="$SRV_DIR/.srv-state"
FIRST_RUN=1; [[ -f "$SRV_STATE" ]] && FIRST_RUN=0
HAS_REMOTE=0
have git && [[ -d "$SRV_DIR/.git" ]] && git -C "$SRV_DIR" remote 2>/dev/null | grep -q . && HAS_REMOTE=1

if (( ! PRUNE )); then
    say "skipped (--keep-all)"
elif (( ! PRUNE_FORCED )) && (( ! FIRST_RUN )); then
    say "skipped — already pruned on this machine (force with --prune)"
elif (( ! PRUNE_FORCED )) && (( HAS_REMOTE )); then
    say "skipped — this bundle has a git remote, so it stays complete for the"
    say "other machines that pull from it (force with --prune)"
else
    # Host profiles for the other machines. generic.sh stays as the fallback
    # shell/env.sh uses if this profile is ever missing.
    for profile in "$SRV_DIR"/hosts/*.sh; do
        base="$(basename "$profile" .sh)"
        case "$base" in
            generic|"$SRV_HOST") continue ;;
        esac
        drop "hosts/$base.sh" "not this machine"
    done

    # SLURM, on a machine with no scheduler.
    if (( ! HAS_SLURM )); then
        drop shell/slurm.zsh "no SLURM here"
    fi

    # Cluster-specific agent skills, on a machine that is not a cluster.
    if [[ "$SRV_CLASS" != princeton ]]; then
        for skill in della della-slurm princeton-storage; do
            drop "claude/skills/$skill" "not a Princeton machine"
        done
    fi

    # conda templates, where conda was declined and is not installed.
    if [[ "$CONDA_CHOICE" == no ]] && ! have conda; then
        drop conda "conda declined"
    fi

    (( ${#PRUNED[@]} )) || say "nothing to prune — every file in this bundle applies here"
fi

# The zip this machine was set up from. Keeping it means the next person to
# look in $HOME finds a stale copy of a bundle that has since been pruned.
# `unzip -q server.zip` leaves it next to the bundle, which is usually $HOME
# but not always; both are the same file when it is.
#
# First install only: make-bundle.sh writes ~/server.zip too, and a later
# srvsync on the machine that builds the bundle must not delete what it has
# just built. And only once the bundle is at ~/server: configured in place
# with --here, a zip beside it may be the source it was unpacked from — or
# the copy a website serves.
if (( FIRST_RUN )) && [[ "$SRV_DIR" == "$DEST" ]]; then
    seen_zip=""
    for zip in "$HOME/server.zip" "$(dirname "$SRV_DIR")/server.zip"; do
        [[ -f "$zip" ]] || continue
        zip="$(cd "$(dirname "$zip")" && pwd)/server.zip"
        [[ "$zip" == "$seen_zip" ]] && continue
        seen_zip="$zip"
        if (( DRY_RUN )); then
            say "would remove $zip"
        else
            rm -f "$zip"; say "removed $zip"
        fi
    done
fi


# Remember that setup has completed here, so the prune rules above can tell a
# first install from a later srvsync.
if (( ! DRY_RUN )); then
    { printf 'first_setup=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
      printf 'host=%s\n' "$SRV_HOST"
      printf 'pruned=%s\n' "$( (( PRUNE )) && echo yes || echo no )"
    } > "$SRV_STATE" 2>/dev/null || true
fi


# ---------------------------------------------------------------------------
step "Version control"
# ---------------------------------------------------------------------------
# The pre-push hook is the git-side counterpart to make-bundle.sh's check: it
# is the other route by which a weak-marked credential blob could reach the
# internet, and the easier one to take by accident.
install_hook() {
    local src="$SRV_DIR/git/hooks/pre-push" dst="$SRV_DIR/.git/hooks/pre-push"
    [[ -f "$src" && -d "$SRV_DIR/.git" ]] || return 0
    if [[ -f "$dst" ]] && cmp -s "$src" "$dst"; then
        say "ok   pre-push hook"
    elif (( DRY_RUN )); then
        say "would install the pre-push hook"
    else
        mkdir -p "$(dirname "$dst")"
        cp "$src" "$dst" && chmod +x "$dst"
        say "installed the pre-push hook (blocks pushing a weak credential blob)"
    fi
}

# A local repo, so the pruning above and every later edit is recoverable even
# on a machine that never gets a remote.
if ! have git; then
    say "git is not installed — skipping"
elif (( DRY_RUN )); then
    say "would commit any changes in $SRV_DIR"
elif [[ -d "$SRV_DIR/.git" ]]; then
    if [[ -n "$(git -C "$SRV_DIR" status --porcelain)" ]]; then
        git -C "$SRV_DIR" add -A
        git -C "$SRV_DIR" commit -q -m "setup on $(hostname -s): profile $SRV_HOST" || true
        say "committed this machine's changes"
    else
        say "ok   clean"
    fi
else
    git -C "$SRV_DIR" init -q
    git -C "$SRV_DIR" add -A
    git -C "$SRV_DIR" commit -q -m "Import bundle on $(hostname -s) (profile: $SRV_HOST)"
    say "initialised a repo — add a remote to sync with your other machines:"
    say "  git -C ~/server remote add origin <url> && git -C ~/server push -u origin main"
fi
install_hook


# ---------------------------------------------------------------------------
step "Done"
# ---------------------------------------------------------------------------
if (( DRY_RUN )); then
    say "dry run — nothing was changed"
else
    say "bundle  : $SRV_DIR"
    say "profile : $SRV_HOST ($SRV_CLASS/$SRV_OS)"
    [[ -d "$SRV_BACKUP_DIR" ]] && say "replaced files backed up in $SRV_BACKUP_DIR"
    printf '\n   Start a new shell and check what resolved here:\n'
    printf '     exec zsh && srvinfo\n\n'
fi
