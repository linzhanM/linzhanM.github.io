---
name: princeton-storage
description: Princeton Research Computing data storage — filesystem tiers (/home, /scratch/gpfs, /projects, /tigress, TigerData, node-local /tmp), quotas and checkquota, backup/purge policies, where jobs should read/write, and data transfer (scp, rsync, rclone, Globus, OnDemand). Use for questions about where to put data on Princeton clusters (Della, Tiger, Stellar, Adroit), quota errors, "disk full"/file-count limits, backing up or archiving results, restoring files, or moving data on/off the clusters.
---

# Princeton Research Computing: data storage

Distilled from https://researchcomputing.princeton.edu/support/knowledge-base/data-storage plus facts verified live on Della (2026-08-25). Sizes/quotas below are as observed for one ARORA-group account; group numbers differ per group.

## The tiers — where data should live

| Filesystem | Size/quota (observed) | Backed up | Purpose |
|---|---|---|---|
| `/home/<netid>` | 50 GB, 2M files (Della) | **Yes** | source code, scripts, conda/venv envs, small software. Never heavy job I/O. |
| `/scratch/gpfs/...` | 14 PB GPFS on Della; group fileset quotas (ARORA: 210 TB, 100M files) | **NO** | job input/output, datasets, checkpoints — the only place jobs should do heavy I/O |
| `/projects/<Group>` | 25 PB (NFS); default user quota 512 GB | Yes | **slow** storage for backing up completed work only; do **not** read/write it from running jobs — stage to scratch first |
| `/tigress/<Group>` | legacy GPFS | Yes | being phased out in favor of /projects & TigerData |
| `/tigerdata/<Group>` | 36 PB tiered storage (TigerData) | managed | large-scale project/archival data with data-management features; portal: https://tigerdata.princeton.edu |
| node-local `/tmp`, `/scratch` (NVMe) | ~100s GB–TBs per node | no, wiped | fast per-job temporary space on compute nodes (feature `nvme`) |

On **Adroit** the fast scratch filesystem is `/scratch/network` instead of `/scratch/gpfs` (Della/Stellar/Tiger). Default per-user scratch quota is 512 GB on clusters without a group fileset arrangement.

Rule of thumb: **code in `/home`, active data in `/scratch/gpfs`, keepers in `/projects` (or TigerData), nothing precious only on scratch** — scratch is not backed up; losing it must be survivable. Copy irreplaceable results off scratch as they are produced.

Here scratch is the group fileset `/scratch/gpfs/ARORA/<netid>` — `$SCRATCH` in any shell this bundle set up (there may be no personal `/scratch/gpfs/<netid>`); PLI members also have TigerData space under `/tigerdata/pli/`.

## Quotas

- `checkquota` — usage + limits for home and scratch (both bytes AND file counts; jobs die on either). Group fileset shows "Used by ALL" vs your share.
- Quota increases: https://forms.rc.princeton.edu/quota
- File-count exhaustion is as common as byte exhaustion (conda envs, many small files). Count files: `find <dir> | wc -l`. Tar up cold directories, keep conda envs few.
- `Disk quota exceeded` in `/home` → check `checkquota`; clear caches (`~/.cache`, pip/conda caches: `pip cache purge`, `conda clean --all`), move data to scratch.

## Backups & recovery

- `/home` and `/projects`/`/tigress` are backed up; `/scratch/gpfs` is **never** backed up (and may be subject to announced purge policies — don't rely on old files).
- Accidentally deleted a backed-up file: open a ticket (email cses@princeton.edu) with the full path and approximate deletion date. No user-visible `.snapshots` on Della home (verified) — recovery goes through support.

## Data transfer

- Small/medium (≲100 GB): `scp`, `rsync -avP`, `sftp` directly to `della.princeton.edu` (VPN off-campus). Prefer `rsync` — restartable.
  `rsync -avP mydir/ <netid>@della.princeton.edu:/scratch/gpfs/ARORA/<netid>/mydir/`
- Large transfers / between institutions: **Globus** (web UI, auto-restart, parallel streams) — use the Princeton endpoints for the cluster/TigerData; https://myglobus.princeton.edu or globus.org with Princeton login.
- Cloud storage (Drive, S3, Dropbox…): `rclone` (installed on Della head nodes: `/usr/bin/rclone`); run `rclone config` once.
- Browser: MyDella/OnDemand file manager (https://mydella.princeton.edu) uploads/downloads without VPN — fine for small files.
- Mount `/tigress`//`/projects` on your own machine via SMB (`tigress-cifs.princeton.edu`, on-campus/VPN) — see KB article "Using tigress-cifs".
- Between Princeton filesystems (scratch ↔ projects ↔ tigerdata): plain `cp`/`rsync` on a head node — all are mounted on Della login nodes (verified). For multi-TB internal moves, use Globus or run rsync in `tmux`/a Slurm job.
- HuggingFace/dataset downloads: run on head node or a job to scratch, never to `/home`.

## Job I/O practices

- `cd /scratch/gpfs/...` in sbatch scripts; never run jobs against `/home`, `/projects`, or `/tigress`.
- Many-small-file workloads: use node-local `/tmp` (or NVMe `/scratch`) during the job, then tar results back to GPFS.
- Checkpoints: write to scratch, prune old ones — they burn group quota fast.
