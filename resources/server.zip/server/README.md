# server

Everything needed to turn a bare machine into one I can work on: shell, git,
tmux, editor, the coding agents, and the per-cluster knowledge that makes the
same config behave correctly on Della and on a laptop.

## Set up a new machine

```bash
curl -fsSLO https://<your-site>/server.zip
unzip -q server.zip && ./server/setup.sh
exec zsh && srvinfo
```

Or without the zip, from a git remote:

```bash
git clone <remote> ~/server && ~/server/setup.sh
```

`setup.sh` is the only entry point and is safe to run twice. It works out what
kind of machine it is on, copies the configs that apply into `$HOME`, installs
the tools that are missing, asks before installing conda, and deletes the
parts of the bundle this machine will never use.

| Flag | Effect |
| --- | --- |
| `--dry-run` | Print every action, change nothing. Worth running first. |
| `--config-only` | Copy configs, install no tools. |
| `--tools=uv,codex` | Run only those installers. |
| `--conda` / `--no-conda` | Answer the conda question up front. |
| `--gdrive` / `--no-gdrive` | Answer the Google Drive question up front. |
| `--keep-all` | Never prune; keep every cluster profile. |
| `--prune` | Prune even when the rules below would skip it. |
| `--no-secrets` | Do not offer to unlock the bundled encrypted credentials. |
| `--secrets` | Unlock them without asking first. |
| `--yes` | Accept every prompt — unattended runs. |
| `--here` | Configure from where the bundle is instead of moving it to `~/server`. |

## What it sets up

| | |
| --- | --- |
| **zsh** | oh-my-zsh, powerlevel10k, autosuggestions, syntax highlighting. `~/.zshrc`, `~/.p10k.zsh`. |
| **bash** | The same environment for SLURM scripts and `ssh host cmd`; hands interactive logins to zsh. |
| **git** | `~/.gitconfig`, global ignore. Credentials are per-machine (see below). |
| **tmux** | gpakosz/.tmux vendored, TPM cloned, my overrides in `tmux.conf.local`. |
| **Neovim** | A release tarball into `~/software` where the system copy is old or absent, plus kickstart.nvim. |
| **CLI tools** | `fzf`, `rg`, `fd`, `bat`, `eza`, `gh`, `git-lfs` as user-local static binaries in `~/.local/bin`. These matter more on a cluster than a laptop: no sudo, ancient system binaries, and a slow shared filesystem where `grep -r` hurts. `git-lfs` because `git/gitconfig` marks its filter required. |
| **rclone** | A static build in `~/.local/bin`. The `gdrive` remote (Google Drive) is **a question, like conda**: its consent needs a browser, or a token pasted from a laptop on a headless cluster. A remote restored from the encrypted bundle is already there, and then nothing is asked. |
| **uv** | The Python/venv manager, cache pointed at scratch. |
| **Claude Code** | Native installer to `~/.local/bin/claude`; seeds `~/.claude/settings.json` and, on a Princeton machine, copies in my cluster skills. |
| **Codex** | Standalone installer to `~/.local/bin/codex`; seeds `~/.codex/config.toml`. |
| **VS Code** | Turns off the Python extensions' terminal auto-activation — see below. Skipped where there is no `~/.vscode-server`. |
| **conda** | **Only if you say yes.** Most machines already have it — from a cluster module, from Homebrew, or not needed because a project uses uv. Declining still writes `~/.condarc` if conda turns up later. |

Neither agent's credentials travel in the bundle. On a new machine run
`claude` once and `codex login` once.

## Layout

```
server/
├── setup.sh              the entry point
├── make-bundle.sh        builds server.zip and install.sh
├── secrets.sh            lock / unlock the encrypted credentials
├── lib/                  sourced, never run: common.sh (script helpers),
│                         detect.sh (which machine, from the profiles' headers)
├── shell/                zshrc, bashrc, env.sh, aliases, functions, slurm
├── hosts/                one declarative profile per machine; generic.sh is
│                         the template
├── tools/                one idempotent installer per tool
├── git/ tmux/ conda/ vscode/ claude/ codex/
│                         one configuration directory per tool, named as the
│                         tool (and its installer in tools/) is
├── secrets/              secrets.enc, and the ~/.secrets.env template
└── web/                  template for the curl | bash installer
```

Three naming rules hold throughout. A file that is copied into `$HOME` is
named as its target is, without the leading dot (`shell/zshrc` → `~/.zshrc`,
`git/ignore` → `~/.config/git/ignore`). `tools/<x>.sh` installs the command
`x`, and `<x>/` is that tool's configuration. A `.template` is rendered
(`__PLACEHOLDER__`s substituted); an `.example` is copied for you to fill in.

`shell/env.sh` is the file that matters most: it is sourced by **both** bash
and zsh, so an interactive login, `ssh host cmd` and `srun --pty bash -l` all
get the same `PATH`, `$SCRATCH`, caches and tokens. A SLURM batch script
reads no rc file at all; it gets them because `sbatch` exports the submitting
shell's environment — so submit from a shell this bundle set up, or `source
~/.bashrc` at the top of the script.

## How machine differences are handled

Everything about a machine is in one file, `hosts/<name>.sh`, and the engine
knows no machine by name. A profile claims its hosts in a header line that
`lib/detect.sh` reads before sourcing anything:

```
# hosts: della* *.della.*      shell patterns on the hostname, full or short
# domain: *.princeton.edu      a site's fallback, tried after every hosts: line
# os: macos                    the last resort, by operating system
```

First match wins, in that order. `detect.sh` then sets `SRV_OS` and
`SRV_HOST` and sources the profile, which sets every other `SRV_*` value —
the same variables in the same order in every profile (`hosts/generic.sh` is
the annotated template):

| | |
| --- | --- |
| `SRV_SITE` | A family of machines sharing a fallback profile, `hosts/<site>.sh`, which pruning keeps with them. |
| `SRV_SCRATCH_CANDIDATES` | Writable directories, best first; `$SCRATCH` is the first that exists, else `$HOME`. |
| `SRV_MODULES` | Environment modules for interactive shells, named without versions. |
| `SRV_CONDA_ROOT`, `SRV_CONDA_TREE` | A fixed conda install, or a directory of releases of which the newest is used — for shells with no module system. |
| `SRV_SLURM_ACCOUNT`, `SRV_SLURM_GPU_PARTITION`, `SRV_SLURM_WATCH_PARTITIONS` | Defaults for the SLURM helpers; empty means SLURM's own default, `--gres` alone, every partition. |
| `SRV_SKILLS` | The `claude/skills/<name>` this machine gets; the rest are pruned. |
| `SRV_OMP_NUM_THREADS`, `SRV_EXTRA_PATH` | Thread count (empty lets libraries decide) and extra `PATH` entries. |

A profile is purely declarative — it sets values and runs nothing. All the
behaviour lives in `shell/env.sh` and `shell/zshrc`, so every machine runs
identical code with different inputs. Preset `SRV_HOST` to force a profile.

Missing pieces degrade instead of failing: a module that does not exist here
is skipped and listed by `srvinfo`, an unknown machine falls back to
`generic`, `$SCRATCH` falls back to `$HOME`, and the SLURM helpers vanish
where there is no scheduler.

Genuinely one-off things — a stray `PATH` entry on one box, a different proxy
— go in `~/.zshrc.local`, `~/.bashrc.local` or `~/.gitconfig.local`. Those are
sourced last and are not in this bundle.

### Adding a machine

1. Copy `hosts/generic.sh` to `hosts/<name>.sh`, replace its `# os:` line
   with `# hosts: <patterns>`, and fill in the values — check the real ones
   with `module avail`, `sinfo -s` and `sacctmgr show assoc user=$USER`.
2. Commit, then `srvsync` on that machine.

Nothing else changes: not `detect.sh`, not `setup.sh`, not `make-bundle.sh`.

The Della, Tiger, Stellar and Adroit profiles were checked against Research
Computing's cluster pages on 2026-09-13 (login nodes, scratch, partitions,
whether an account is needed). Only Della runs through the Arora lab
(`arora`, partition `pli-c`, scratch under `/scratch/gpfs/ARORA`); every
other cluster uses my own account, `lm2052`, names no partition, and takes
the personal scratch. Ionic and Neuronic are the CS department's clusters,
which RC does not document, so their storage and modules are still
`# VERIFY`. Modules are named without versions and resolve to the site
default, or to the newest installed where the site defines none (Stellar).

## Copies, not symlinks

Configs are **copied** into `$HOME`. `$HOME` therefore stays self-contained:
if this directory is moved, renamed or deleted the shell still starts and
prints one line saying so — it only loses the pieces read from `$SRV_DIR` at
startup rather than copied: `shell/env.sh` (`$SCRATCH`, the caches, the extra
`PATH` entries) and the `aliases`, `functions` and `slurm` zsh modules.

The cost is that editing `~/.zshrc` no longer edits the bundle, so the traffic
goes both ways:

- **`srvpull`** — copy this machine's live configs back into the bundle.
- **`srvsync`** — pull from the git remote (if there is one) and re-run
  `setup.sh`, which copies the bundle's version back out.

`setup.sh` never deletes anything of yours: a file it replaces is moved to
`~/.server-backup/<timestamp>/` first.

## Pruning

Once a machine knows what it is, the profiles for the other clusters are dead
weight, so `setup.sh` removes them: the other `hosts/*.sh` (the profile's
site fallback and `generic.sh` stay), `shell/slurm.zsh` where there is no
scheduler, every agent skill the profile's `SRV_SKILLS` does not name,
`conda/` if you declined conda, and the `server.zip` it was unpacked from.
It commits the result, so `git log` in `~/server` shows exactly what was
dropped.

It is a **first-install** action (so is removing the zip — `make-bundle.sh`
writes `~/server.zip` too, and a later `srvsync` must not delete a bundle
just built there), and two rules stop it doing damage later:

- **Already pruned here.** Recorded in `.srv-state`. Without this, every
  `srvsync` would delete profiles that the `git pull` immediately before it
  had just restored.
- **This bundle has a git remote.** Then it is the shared copy the other
  machines pull from, and their profiles have to survive. A local prune commit
  would also diverge from the remote and break the next `git pull --ff-only`.

`--prune` overrides both; `--keep-all` disables pruning outright. Use
`--keep-all` on whichever machine you rebuild the bundle from, since
`make-bundle.sh` can only ship what is still there — it warns when
`.srv-state` records a prune, and lists from `git log` what went.

## Secrets

API tokens live in `~/.secrets.env`, mode 600, sourced by `shell/env.sh` so
SLURM jobs get them too. A new machine gets them one of three ways, and
`setup.sh` tries them in this order.

**1. Encrypted, inside the bundle.** Lock them once:

```bash
srvlock                # or: srvlock --with-ssh
git -C ~/server add -A && git -C ~/server commit -m "Update secrets"
./make-bundle.sh
```

It carries more than the env file, because the things that make a new machine
immediately useful are files rather than variables:

| Carried | Why |
| --- | --- |
| `~/.secrets.env` | The API tokens themselves. |
| `~/.git-credentials` | `git push` works on arrival — no re-auth to GitHub or the Hub. |
| `~/.config/rclone/rclone.conf` | Moving data works on arrival. |
| `~/.ssh/id_*` | **Opt-in** (`--with-ssh`). One key on every machine means one stolen machine burns them all; a per-machine key added to GitHub is strictly better. |

Deliberately left out: `~/.codex/auth.json` and `~/.claude.json` are session
credentials that expire (and the latter is mostly project state) — `codex
login` and running `claude` once are quicker than debugging a stale copy. And
`~/.cache/huggingface/token` is redundant, since `huggingface_hub` reads
`$HF_TOKEN`.

From then on, unzipping on a new machine asks for the passphrase and writes
`~/.secrets.env` (mode 600) itself. `srvunlock` does it later or again;
`--no-secrets` skips the prompt; `SRV_SECRETS_PASSPHRASE` covers unattended
runs.

The file is a gzipped tar, AES-256-CBC with the key from PBKDF2-HMAC-SHA512
over 2,000,000 iterations — about a second to unlock, and the thing that makes
brute force expensive. gzip's magic bytes plus a marker file inside are how a
wrong passphrase fails loudly, because openssl alone will happily hand back
garbage. Everything is staged and validated in a temp directory before
anything in `$HOME` is touched, and modes are preserved, so
`~/.git-credentials` comes back 600 without anyone remembering to chmod it.

> **The passphrase is the entire security boundary.** If the bundle is
> reachable — a public URL, a repo that later goes public, a laptop that
> leaves — assume someone has the ciphertext and can grind at it offline
> forever, on as much hardware as they care to rent. A generated passphrase or
> five random words makes that hopeless; anything memorable does not. `srvlock`
> refuses passphrases under 12 characters, refuses the shapes crackers model
> first (initials plus a date plus a symbol), and offers to generate one. It
> also refuses to print a generated passphrase inside a coding-agent session,
> where it would land in a transcript. Rotate
> the tokens periodically regardless: ciphertext copied today is still
> crackable in ten years.
>
> **The choice is recorded, not re-asked.** If you override the warning and
> keep a weak passphrase, `lock` marks the blob `strength: weak` in its header
> and `make-bundle.sh` then leaves it out of the zip by default — the safe
> combination for a memorable passphrase is exactly "encrypted, but not
> published". Carry it by hand instead:
>
> ```bash
> scp ~/server/secrets/secrets.enc <host>:~/server/secrets/
> ```
>
> `--with-secrets` overrides that and puts it in anyway; `--no-secrets` leaves
> a strong one out.

**2. Copied across out of band.** Always available, nothing to remember:

```bash
scp ~/.secrets.env <host>:~/.secrets.env && ssh <host> chmod 600 ~/.secrets.env
```

**3. Typed in.** With neither of the above, `setup.sh` seeds
`~/.secrets.env` from `secrets/secrets.env.example` for you to fill in.

Plaintext secrets are never committed and never bundled: `.gitignore` blocks
them and `make-bundle.sh` refuses to build if anything token-shaped other than
`secrets/secrets.enc` has found its way in.

## GitHub

`git/gitconfig` carries the identity, aliases and the `store` credential
helper; the credentials themselves are per-machine and deliberately absent.
Set them up once on a new box with either:

```bash
git credential approve        # then paste protocol/host/username/password
# or, for SSH:
ssh-keygen -t ed25519 -C "$(git config user.email)" && cat ~/.ssh/id_ed25519.pub
```

## Rebuilding the bundle

```bash
srvpull                # fold any in-place edits back into the bundle
./make-bundle.sh       # -> ~/server.zip
```

Then upload `server.zip` to the website. Build it on an unpruned copy, or the
new bundle will only know about the machine that built it.

## Notes

`tmux/tmux.conf` is [gpakosz/.tmux](https://github.com/gpakosz/.tmux) verbatim
and marked do-not-edit upstream; it is vendored so every machine runs the same
version, and `srvpull` never copies it back. My changes go in
`tmux/tmux.conf.local`, which it sources at the end.

`~/.config/nvim` is a clone of kickstart.nvim that syncs itself through its
own git remote, so it is cloned rather than vendored.

`conda/ml-env.yml` recreates the `ml` environment:
`conda env create -f conda/ml-env.yml`.

## Why VS Code kept typing `conda activate` at you

Both Python extensions activate the selected interpreter in every new
integrated terminal, and `python-envs.terminal.autoActivationType` defaults to
`"command"` — meaning the extension *types* `conda activate <env>` into the
shell. If you are already typing, the injected text lands in the middle of
your command line, which is where history entries like

```
ls  conda activate unimate
```

come from. `vscode/settings.json` sets that to `"off"` and
`python.terminal.activateEnvironment` to `false`; `tools/vscode.sh` merges them
into `~/.vscode-server/data/Machine/settings.json` without disturbing whatever
else is in there. Nothing is lost — `shell/env.sh` already puts conda on `PATH`
and defines the shell function, so `conda activate` works whenever you ask for
it. Reload the VS Code window for it to take effect.

## What is not automatic

Everything in `tools/` downloads and installs itself, but three things cannot:

- **zsh itself.** Installing a shell needs a package manager and root. The
  clusters already have it; on a bare VM `setup.sh` tells you the one command
  to run (`sudo apt install zsh`) and carries on. Everything else still works
  — `~/.bashrc` gives you the same environment and hands over to zsh once it
  exists.
- **tmux plugins.** TPM is cloned, but it fetches the plugins itself: start
  tmux and press `prefix + I` once.
- **Signing in.** `claude` once, `codex login` once. Those credentials are
  deliberately not in the bundle.

Note that `chsh` is never needed. `~/.bash_profile` → `~/.bashrc` → `exec zsh`
covers the handoff, which matters on clusters where the login shell is
centrally managed and `chsh` is disabled.
