# hosts/della.sh — Princeton Della (della*.princeton.edu)
#
# Declarative only: set SRV_* variables, run nothing. shell/env.sh and
# shell/zshrc are what act on them, so every machine runs identical code with
# different values.

# Scratch, highest preference first. The group directory is where the Arora
# lab's quota lives; the per-user one is the fallback.
SRV_SCRATCH_CANDIDATES="/scratch/gpfs/ARORA/$USER /scratch/gpfs/$USER"

# Environment modules loaded in interactive shells. A module that does not
# exist here is skipped and reported by `srvinfo`, so pinning versions is safe
# across cluster upgrades.
SRV_MODULES="anaconda3/2025.6 cudatoolkit/12.6 openmpi/cuda-12.6/gcc/4.1.6"

# conda root for non-interactive shells, which have no module system.
SRV_CONDA_ROOT="/usr/licensed/anaconda3/2025.6"

# SLURM defaults used by shell/slurm.zsh.
SRV_SLURM_ACCOUNT="arora"
SRV_SLURM_GPU_PARTITION="pli-c"
SRV_SLURM_WATCH_PARTITIONS="pli,pli-c"

# Della head nodes have 32 physical cores.
SRV_OMP_NUM_THREADS=32

# Locally installed software.
SRV_EXTRA_PATH="$HOME/software/blender-3.2.2-linux-x64 $HOME/software/nvim-linux64/bin"

# Blender's bundled Python, exported as $BPY and used by the `bpy` alias.
SRV_BPY="$HOME/software/blender-3.2.2-linux-x64/3.2/python/bin/python3.10"
