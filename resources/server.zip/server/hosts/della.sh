# hosts/della.sh — Princeton Della (della.princeton.edu)
# hosts: della* *.della.*
#
# Declarative only: set SRV_* values, run nothing. lib/detect.sh reads the
# `# hosts:` line above to know this file is for these machines; shell/env.sh
# and shell/zshrc act on the values, so every machine runs identical code.
#
# From researchcomputing.princeton.edu/systems/della (read 2026-09-13): the
# general-purpose RC cluster, open to all groups. Login nodes della9
# (della.princeton.edu), della-gpu (GPU builds and jobs), della-vis1/2 and
# the GH200 login; compute nodes such as della-r3c1n1, della-l04g1. RHEL 9,
# AMD CPU nodes. Partitions cpu (default), gpu, mig, grace, and the
# restricted pli / pli-c / pli-p / pli-lc (PLI, H100) and ailab. QOS is
# assigned from --time; never set it. This is the one cluster used through
# the Arora lab: its account, partition and group scratch.

SRV_SITE="princeton"

# Scratch, highest preference first: the group fileset (where the lab's quota
# lives), then a personal one.
SRV_SCRATCH_CANDIDATES="/scratch/gpfs/ARORA/$USER /scratch/gpfs/$USER"

# Modules loaded in interactive shells, unversioned: the site default, or the
# newest installed where the site defines none (shell/zshrc). A project that
# needs a version, or an MPI, pins it in its own job script. RC's advice is to
# load modules in job scripts rather than shell startup; this is the
# interactive convenience only — batch jobs never read it.
SRV_MODULES="anaconda3 cudatoolkit"

# conda for non-interactive shells, which have no module system: the newest
# release under the site's tree (shell/env.sh).
SRV_CONDA_ROOT=""
SRV_CONDA_TREE="/usr/licensed/anaconda3"

# SLURM defaults for shell/slurm.zsh.
SRV_SLURM_ACCOUNT="arora"
SRV_SLURM_GPU_PARTITION="pli-c"
SRV_SLURM_WATCH_PARTITIONS="pli,pli-c"

# Agent skills (claude/skills/<name>) this machine gets; the rest are pruned.
SRV_SKILLS="della della-slurm princeton-storage"

# Head nodes have 32 physical cores.
SRV_OMP_NUM_THREADS=32

# Locally installed software, and Blender's bundled Python as $BPY.
SRV_EXTRA_PATH="$HOME/software/blender-3.2.2-linux-x64 $HOME/software/nvim-linux64/bin"
SRV_BPY="$HOME/software/blender-3.2.2-linux-x64/3.2/python/bin/python3.10"
