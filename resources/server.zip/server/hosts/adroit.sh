# hosts/adroit.sh — Princeton Adroit (adroit.princeton.edu)
# hosts: adroit* *.adroit.*
#
# From researchcomputing.princeton.edu/systems/adroit (read 2026-09-13): the
# small cluster for small parallel jobs, training and classes, with its own
# filesystem. Login node adroit; adroit-vis for visualization and downloads.
# Scratch is /scratch/network/<netid> (NFS, ~70 TB, not backed up) — there is
# no /scratch/gpfs here. Partitions all (64-core nodes) and class (32-core);
# three GPU nodes reached with --gres=gpu:1 and a constraint (a100, a40,
# gpu80), no GPU partition. QOS follows --time: test ≤ 15 min, short ≤ 4 h,
# medium ≤ 24 h, long ≤ 7 days. Used under my own account.

SRV_SITE="princeton"

SRV_SCRATCH_CANDIDATES="/scratch/network/$USER"

SRV_MODULES="anaconda3"

SRV_CONDA_ROOT=""
SRV_CONDA_TREE="/usr/licensed/anaconda3"

SRV_SLURM_ACCOUNT="lm2052"
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_SKILLS="princeton-storage"

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
