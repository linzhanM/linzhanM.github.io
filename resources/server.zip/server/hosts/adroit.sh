# hosts/adroit.sh — Princeton Adroit (adroit*.princeton.edu)
#
# Adroit is the small teaching cluster: no lab allocation, so no account is
# set and jobs go to the default partitions.
#
# Values marked VERIFY were not confirmed on the machine itself.

SRV_SCRATCH_CANDIDATES="/scratch/network/$USER /scratch/gpfs/$USER"

SRV_MODULES="anaconda3/2025.6"                           # VERIFY versions
SRV_CONDA_ROOT="/usr/licensed/anaconda3/2025.6"          # VERIFY version

SRV_SLURM_ACCOUNT=""                                     # none on Adroit
SRV_SLURM_GPU_PARTITION="gpu"                            # VERIFY
SRV_SLURM_WATCH_PARTITIONS="gpu"                         # VERIFY

SRV_OMP_NUM_THREADS=8
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
