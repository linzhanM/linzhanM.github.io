# hosts/neuronic.sh — Princeton PNI cluster (neuronic.princeton.edu)
#
# Everything here is marked VERIFY — it was written from the documented
# layout, not from the machine. Correct it on first login.

SRV_SCRATCH_CANDIDATES="/scratch/gpfs/$USER /n/fs/$USER"  # VERIFY

SRV_MODULES="anaconda3/2025.6"                           # VERIFY
SRV_CONDA_ROOT="/usr/licensed/anaconda3/2025.6"          # VERIFY

SRV_SLURM_ACCOUNT=""                                     # VERIFY
SRV_SLURM_GPU_PARTITION="gpu"                            # VERIFY
SRV_SLURM_WATCH_PARTITIONS="gpu"                         # VERIFY

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
