# hosts/neuronic.sh — Princeton CS department GPU cluster (neuronic.cs.princeton.edu)
# hosts: neuronic* *.neuronic.*
#
# NOT a Research Computing system (RC's site has no page for it; checked
# 2026-09-13), so nothing documented for the RC clusters — /scratch/gpfs,
# /usr/licensed, the anaconda3 module — can be assumed. Run by CS, like
# ionic, with storage under /n/fs. Lines marked VERIFY are guesses — confirm
# on first login. Used under my own account.

SRV_SITE="princeton"

SRV_SCRATCH_CANDIDATES="/n/fs/scratch/$USER $HOME/scratch"   # VERIFY

SRV_MODULES=""                                               # VERIFY

SRV_CONDA_ROOT=""            # env.sh probes ~/miniconda3, ~/miniforge3 …
SRV_CONDA_TREE=""

SRV_SLURM_ACCOUNT="lm2052"
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_SKILLS=""                # the RC skills describe RC storage, not /n/fs

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
