# hosts/stellar.sh — Princeton Stellar (stellar*.princeton.edu)
#
# Values marked VERIFY were written from the documented defaults, not from the
# machine. Check them on first login and correct them here.

SRV_SCRATCH_CANDIDATES="/scratch/gpfs/ARORA/$USER /scratch/gpfs/$USER"

SRV_MODULES="anaconda3/2025.6"                           # VERIFY versions
SRV_CONDA_ROOT="/usr/licensed/anaconda3/2025.6"          # VERIFY version

SRV_SLURM_ACCOUNT="arora"                                # VERIFY
SRV_SLURM_GPU_PARTITION="gpu"                            # VERIFY
SRV_SLURM_WATCH_PARTITIONS="all,gpu"                     # VERIFY

SRV_OMP_NUM_THREADS=16
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
