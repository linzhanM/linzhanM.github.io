# hosts/stellar.sh — Princeton Stellar (stellar.princeton.edu)
# hosts: stellar* *.stellar.*
#
# From researchcomputing.princeton.edu/systems/stellar (read 2026-09-13):
# for large multinode jobs in astrophysics, plasma physics, physics, CBE and
# AOS. Login nodes stellar-intel (stellar.princeton.edu, PU and PPPL) and
# stellar-amd (CIMES); stellar-vis1 (PU) / stellar-vis2 (PPPL). Scratch is
# /scratch/gpfs (CIMES: /scratch/cimes). Partitions pu, pppl, cimes, serial
# (a pu/pppl job of ≤ 47 cores, lowest priority), bigmem, gpu (A100),
# stellar-debug. Nodes are 96 cores; the default --mem-per-cpu is 7500M, too
# much for the AMD nodes. The site defines no default anaconda3 version, so a
# bare `module load anaconda3` fails — shell/zshrc resolves it to the newest.
# Used under my own account, no partition named.

SRV_SITE="princeton"

SRV_SCRATCH_CANDIDATES="/scratch/gpfs/$USER"

SRV_MODULES="anaconda3"

SRV_CONDA_ROOT=""
SRV_CONDA_TREE="/usr/licensed/anaconda3"

SRV_SLURM_ACCOUNT="lm2052"
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_SKILLS="princeton-storage"

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
