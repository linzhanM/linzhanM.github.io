# hosts/generic.sh — a plain Linux box or cloud VM.
#
# Deliberately minimal: no modules, no SLURM, no assumptions about shared
# filesystems. Anything that is not a known cluster and not a Mac lands here
# and still gets a complete working shell.
#
# Per-machine tweaks that should NOT be synced belong in ~/.zshrc.local
# rather than in this file.

SRV_SCRATCH_CANDIDATES=""    # env.sh tries /scratch/$USER, then falls back to $HOME

SRV_MODULES=""
SRV_CONDA_ROOT=""

SRV_SLURM_ACCOUNT=""
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_OMP_NUM_THREADS=""       # let libraries size themselves to the machine
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"   # tools/nvim.sh unpacks here
