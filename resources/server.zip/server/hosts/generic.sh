# hosts/generic.sh — a plain Linux box or cloud VM, and the template
# os: linux
#
# Deliberately minimal: no modules, no SLURM, no assumptions about shared
# filesystems. Anything that is not a known machine and not a Mac lands here
# and still gets a complete working shell. It is also the fallback when a
# preset SRV_HOST has no profile, so it is never pruned.
#
# To add a machine, copy this file to hosts/<name>.sh, replace the `# os:`
# line with `# hosts: <shell patterns on the hostname>`, and fill in the
# values. Every profile carries exactly these variables, in this order.
# Per-machine tweaks that should NOT be synced belong in ~/.zshrc.local.

SRV_SITE=""                  # a family of machines sharing a fallback profile (hosts/<site>.sh)

SRV_SCRATCH_CANDIDATES=""    # writable dirs, best first; env.sh tries /scratch/$USER, then $HOME

SRV_MODULES=""               # environment modules for interactive shells, unversioned

SRV_CONDA_ROOT=""            # a fixed conda install, for shells with no module system
SRV_CONDA_TREE=""            # or a directory of conda releases: the newest is used

SRV_SLURM_ACCOUNT=""         # --account for shell/slurm.zsh; empty means SLURM's default
SRV_SLURM_GPU_PARTITION=""   # --partition for GPU allocations; empty means --gres alone
SRV_SLURM_WATCH_PARTITIONS="" # what `sg` reports on; empty means every partition

SRV_SKILLS=""                # claude/skills/<name> to install here; the rest are pruned

SRV_OMP_NUM_THREADS=""       # empty lets libraries size themselves to the machine
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"   # prepended to PATH, lowest precedence first
