# hosts/ionic.sh — Princeton CS department cluster (ionic.cs.princeton.edu)
# hosts: ionic* *.ionic.*
#
# NOT a Research Computing system (RC's site does not document it; checked
# 2026-09-13): run by CS, so storage is under /n/fs rather than /scratch/gpfs
# and there is no /usr/licensed anaconda. Lines marked VERIFY are guesses —
# confirm on first login with `module avail`, `sinfo -s` and
# `sacctmgr show assoc user=$USER`. Used under my own account.

SRV_SITE="princeton"

SRV_SCRATCH_CANDIDATES="/n/fs/scratch/$USER $HOME/scratch"   # VERIFY

SRV_MODULES=""                                               # VERIFY

SRV_CONDA_ROOT="$HOME/miniconda3"                            # VERIFY
SRV_CONDA_TREE=""

SRV_SLURM_ACCOUNT="lm2052"
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_SKILLS=""                # the RC skills describe RC storage, not /n/fs

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
