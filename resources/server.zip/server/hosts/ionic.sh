# hosts/ionic.sh — Princeton CS department cluster (ionic.cs.princeton.edu)
#
# Not a Research Computing machine: it is run by CS, so the storage layout is
# /n/fs/<group> rather than /scratch/gpfs, and there is no /usr/licensed
# anaconda. Everything here is marked VERIFY — fill it in on first login with
# `module avail`, `sinfo -s` and `sacctmgr show assoc user=$USER`.

# CS uses per-group fileservers under /n/fs. The last two are the usual
# fallbacks if the group directory has a different name here.
SRV_SCRATCH_CANDIDATES="/n/fs/arora/$USER /n/fs/scratch/$USER $HOME/scratch"  # VERIFY

# No environment-module system by default on ionic; conda comes from a user
# install instead of a site-wide one.
SRV_MODULES=""                                           # VERIFY
SRV_CONDA_ROOT="$HOME/miniconda3"                        # VERIFY

SRV_SLURM_ACCOUNT=""                                     # VERIFY
SRV_SLURM_GPU_PARTITION="gpu"                            # VERIFY
SRV_SLURM_WATCH_PARTITIONS="gpu"                         # VERIFY

SRV_OMP_NUM_THREADS=""       # leave to the library; node sizes vary
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
