# hosts/princeton.sh — a Princeton machine this bundle does not know by name.
#
# lib/detect.sh lands here when the module system or /scratch/gpfs is
# present but the hostname matched no named cluster: an unfamiliar login node,
# a renamed cluster, a new RC machine. The defaults are the ones common to
# every Research Computing system, with nothing lab-specific assumed.
#
# If this machine is going to be used regularly, copy this file to
# hosts/<name>.sh, fill in the real values, and add a pattern to lib/detect.sh.

SRV_SCRATCH_CANDIDATES="/scratch/gpfs/ARORA/$USER /scratch/gpfs/$USER /scratch/network/$USER"

# Unversioned module names resolve to the site default, which is the right
# choice when the available versions here are unknown.
SRV_MODULES="anaconda3"
SRV_CONDA_ROOT=""            # env.sh finds it via the module or ~/miniconda3

SRV_SLURM_ACCOUNT=""         # unknown — SLURM falls back to your default
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
