# hosts/princeton.sh — a Princeton machine no profile knows by name
# domain: *.princeton.edu
#
# lib/detect.sh lands here when the hostname matched no `# hosts:` line but
# is in the Princeton domain: an unfamiliar login node, a renamed cluster, a
# new RC machine. The values are the ones common to every Research Computing
# system, with nothing lab-specific assumed. A machine used regularly gets
# its own file: copy this one to hosts/<name>.sh, put its hostnames on a
# `# hosts:` line, and fill in the real values.

SRV_SITE="princeton"

SRV_SCRATCH_CANDIDATES="/scratch/gpfs/$USER /scratch/network/$USER"

SRV_MODULES="anaconda3"

SRV_CONDA_ROOT=""
SRV_CONDA_TREE="/usr/licensed/anaconda3"

SRV_SLURM_ACCOUNT="lm2052"
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_SKILLS="princeton-storage"

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
