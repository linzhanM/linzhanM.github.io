# hosts/tiger.sh — Princeton Tiger (tiger.princeton.edu)
# hosts: tiger* *.tiger.*
#
# From researchcomputing.princeton.edu/systems/tiger (read 2026-09-13): the
# cluster for large multinode CPU jobs. Login node tigercpu; tiger-vis for
# post-processing and downloads. Scratch is /scratch/gpfs, not backed up;
# /projects is NOT mounted on the compute nodes. GPUs are restricted: H100s
# to select groups (--gres alone, no partition), L40S / H200 to CIMES
# (partition cimes). With several Slurm accounts, --account is required.
# Used under my own account, no partition named.

SRV_SITE="princeton"

SRV_SCRATCH_CANDIDATES="/scratch/gpfs/$USER"

SRV_MODULES="anaconda3 cudatoolkit"

SRV_CONDA_ROOT=""
SRV_CONDA_TREE="/usr/licensed/anaconda3"

SRV_SLURM_ACCOUNT="lm2052"
SRV_SLURM_GPU_PARTITION=""
SRV_SLURM_WATCH_PARTITIONS=""

SRV_SKILLS="princeton-storage"

SRV_OMP_NUM_THREADS=""
SRV_EXTRA_PATH="$HOME/software/nvim-linux64/bin"
