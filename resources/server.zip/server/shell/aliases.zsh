# shell/aliases.zsh — aliases available on every server.

# ---------------------------------------------------------------------------
# Files and navigation
# ---------------------------------------------------------------------------
# eza where it is installed (tools/cli.sh), plain ls where it is not — these
# machines are not all set up to the same level and the alias has to work on
# the ones that are not.
if command -v eza >/dev/null 2>&1; then
  alias ll='eza -lh --git --group-directories-first'
  alias la='eza -lah --git --group-directories-first'
  alias lt='eza --tree --level=2'
else
  alias ll='ls -lh'
  alias la='ls -lAh'
fi

command -v bat >/dev/null 2>&1 && alias cat='bat --paging=never --style=plain'
alias ..='cd ..'
alias ...='cd ../..'

# Count plain files / directories in the current directory.
alias lf='ls -l | grep -c "^-"'
alias ld='ls -l | grep -c "^d"'

# Directory sizes here, largest last.
alias duh='du -sh -- * .[!.]* 2>/dev/null | sort -h'


# ---------------------------------------------------------------------------
# Editor
# ---------------------------------------------------------------------------
# Fall back to the system vim on machines where nvim is not installed.
if command -v nvim >/dev/null 2>&1; then
  alias vim='nvim'
  alias vi='nvim'
fi


# ---------------------------------------------------------------------------
# Machine
# ---------------------------------------------------------------------------
alias srv='cd "$SRV_DIR"'
alias scratch='cd "$SCRATCH"'
alias gpus='nvidia-smi 2>/dev/null || echo "no GPU on $(hostname -s)"'

# checkquota only exists on the Princeton clusters.
alias quota='checkquota 2>/dev/null || df -h "$HOME" "$SCRATCH"'


# ---------------------------------------------------------------------------
# Coding agents
# ---------------------------------------------------------------------------
# All three skip every permission prompt, so file edits go through Claude
# Code's own Edit/Write tools and stay checkpointed for /rewind (auto mode
# routed them through Bash, which leaves nothing to rewind to). An alias only
# fires in interactive command position, so builds that invoke the C compiler
# `cc` through make or CMake are unaffected.
alias ca='claude --dangerously-skip-permissions'
alias cc='claude --dangerously-skip-permissions'
alias cf='claude --model "claude-fable-5-1" --dangerously-skip-permissions'
alias cx='codex'


# ---------------------------------------------------------------------------
# Blender (only where it is actually installed)
# ---------------------------------------------------------------------------
if [[ -n "$BPY" && -x "$BPY" ]]; then
  alias bpy='"$BPY"'
fi
