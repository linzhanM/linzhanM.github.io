# shell/aliases.zsh — aliases available on every server.

# ---------------------------------------------------------------------------
# Files and navigation
# ---------------------------------------------------------------------------
# eza where it is installed (tools/cli.sh), plain ls where it is not — these
# machines are not all set up to the same level and the alias has to work on
# the ones that are not.
if command -v eza >/dev/null 2>&1; then
  alias ll='eza -lh --git --group-directories-first'
  alias la='eza -lah --git --group-directories-first'
  alias lt='eza --tree --level=2'
else
  alias ll='ls -lh'
  alias la='ls -lAh'
fi

command -v bat >/dev/null 2>&1 && alias cat='bat --paging=never --style=plain'
alias ..='cd ..'
alias ...='cd ../..'

# Count plain files / directories in the current directory.
alias lf='ls -l | grep -c "^-"'
alias ld='ls -l | grep -c "^d"'

# Directory sizes here, largest last.
alias duh='du -sh -- * .[!.]* 2>/dev/null | sort -h'


# ---------------------------------------------------------------------------
# Editor
# ---------------------------------------------------------------------------
# Fall back to the system vim on machines where nvim is not installed.
if command -v nvim >/dev/null 2>&1; then
  alias vim='nvim'
  alias vi='nvim'
fi


# ---------------------------------------------------------------------------
# Machine
# ---------------------------------------------------------------------------
alias srv='cd "$SRV_DIR"'
alias scratch='cd "$SCRATCH"'
alias gpus='nvidia-smi 2>/dev/null || echo "no GPU on $(hostname -s)"'

# checkquota only exists on the Princeton clusters.
alias quota='checkquota 2>/dev/null || df -h "$HOME" "$SCRATCH"'


# ---------------------------------------------------------------------------
# Coding agents
# ---------------------------------------------------------------------------
alias ca='claude --permission-mode auto'
alias cf='claude --model "claude-fable-5-1" --permission-mode auto'
alias cx='codex'


# ---------------------------------------------------------------------------
# Blender (only where it is actually installed)
# ---------------------------------------------------------------------------
if [[ -n "$BPY" && -x "$BPY" ]]; then
  alias bpy='"$BPY"'
fi
