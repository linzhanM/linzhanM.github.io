# shell/functions.zsh — general-purpose helpers (non-SLURM).

# mkcd <dir> : create a directory and enter it
mkcd() {
    mkdir -p -- "${1:?Usage: mkcd <dir>}" && cd -- "$1"
}

# tb <logdir> [port] : tensorboard on a given (or random high) port
tb() {
    local logdir="${1:?Usage: tb <logdir> [port]}"
    local port="${2:-$(shuf -i 6000-9999 -n 1 2>/dev/null || echo 6006)}"
    echo "tensorboard -> http://$(hostname -s):$port"
    tensorboard --logdir "$logdir" --port "$port"
}


# ---------------------------------------------------------------------------
# This bundle
# ---------------------------------------------------------------------------

# srvinfo : what this shell actually resolved to on this machine
#
# The first thing to run after setting up a new server. Everything in this
# bundle degrades rather than failing, so this is how you see what degraded:
# which profile matched, which modules were missing, whether the tokens loaded.
srvinfo() {
    local ok="ok" no="—"

    print -r -- "machine     : $SRV_HOST${SRV_SITE:+  [site: $SRV_SITE]}  [$SRV_OS]  ($(hostname -f 2>/dev/null || hostname))"
    print -r -- "bundle      : $SRV_DIR"
    if [[ "$SRV_PROFILE" == "$SRV_DIR/hosts/$SRV_HOST.sh" ]]; then
        print -r -- "profile     : ${SRV_PROFILE#$SRV_DIR/}"
    else
        print -r -- "profile     : hosts/$SRV_HOST.sh is MISSING — using ${SRV_PROFILE#$SRV_DIR/}"
    fi
    [[ -n "$SRV_SKILLS" ]] && print -r -- "skills      : $SRV_SKILLS"
    print -r -- "scratch     : $SCRATCH"
    print -r -- "tmpdir      : $TMPDIR"

    if [[ -n "$SRV_MODULES" ]]; then
        print -r -- "modules     : $SRV_MODULES"
        (( ${#SRV_MODULES_MISSING} )) &&
            print -r -- "              unavailable here: ${SRV_MODULES_MISSING[*]}"
    else
        print -r -- "modules     : (none for this profile)"
    fi

    if [[ -n "$SRV_SLURM_GPU_PARTITION" || -n "$SRV_SLURM_ACCOUNT" ]]; then
        print -r -- "slurm       : account=${SRV_SLURM_ACCOUNT:-(default)}" \
                    "gpu-partition=${SRV_SLURM_GPU_PARTITION:-(default)}"
    elif command -v squeue >/dev/null 2>&1; then
        print -r -- "slurm       : present, no defaults set for this profile"
    else
        print -r -- "slurm       : $no"
    fi

    # `command -v` on a shell function just echoes the name back, which reads
    # like a broken path; conda from a cluster module is always a function.
    local t where
    for t in conda python uv rclone claude codex git zsh tmux nvim; do
        where="$(command -v $t 2>/dev/null)"
        [[ -z "$where" ]] && where="$no"
        [[ "$where" == "$t" ]] && where="(shell function)"
        printf '%-12s: %s\n' "$t" "$where"
    done

    if [[ -r ~/.secrets.env || -r ~/.secrets.zsh ]]; then
        print -r -- "secrets     : loaded"
    elif [[ -r "$SRV_DIR/secrets/secrets.enc" ]]; then
        print -r -- "secrets     : locked in the bundle — run: srvunlock"
    else
        print -r -- "secrets     : MISSING — cp $SRV_DIR/secrets/secrets.env.example ~/.secrets.env"
    fi
    [[ -r ~/.zshrc.local ]] && print -r -- "local       : ~/.zshrc.local loaded"
}

# srvsync : bring this machine up to date with the bundle
#
# Pulls if there is a remote to pull from — a fresh machine set up from
# server.zip has a local repo and no remote, and that is not an error — then
# re-runs setup.sh, which is idempotent.
srvsync() {
    if git -C "$SRV_DIR" remote 2>/dev/null | grep -q .; then
        git -C "$SRV_DIR" pull --ff-only || return 1
    else
        print -r -- "no git remote on $SRV_DIR — re-running setup only"
    fi
    "$SRV_DIR/setup.sh" "$@" || return 1
    print -r -- "reload with: exec zsh"
}

# srvpull : copy this machine's live configs back into the bundle
#
# The counterpart to setup.sh. Configs are copied into $HOME rather than
# symlinked, so editing ~/.zshrc directly does not touch the bundle — this is
# how that edit gets back in, and it is what to run before `srvsync` or
# `make-bundle.sh` if you have been tweaking things in place.
srvpull() {
    local -A files=(
        [.zshrc]=shell/zshrc              [.bashrc]=shell/bashrc
        [.bash_profile]=shell/bash_profile [.p10k.zsh]=shell/p10k.zsh
        [.gitconfig]=git/gitconfig         [.config/git/ignore]=git/ignore
        [.tmux.conf.local]=tmux/tmux.conf.local
    )
    local home_file bundle_file
    for home_file bundle_file in ${(kv)files}; do
        [[ -f "$HOME/$home_file" ]] || continue
        if cmp -s "$HOME/$home_file" "$SRV_DIR/$bundle_file"; then
            print -r -- "  ok   $bundle_file"
        else
            cp "$HOME/$home_file" "$SRV_DIR/$bundle_file"
            print -r -- "  pull $bundle_file  <- ~/$home_file"
        fi
    done
    # tmux.conf itself is upstream and marked do-not-edit, so it is never
    # pulled back; local changes belong in tmux.conf.local, which is.
    print -r -- "review with: git -C $SRV_DIR diff"
}

# srvlock / srvunlock : the API tokens, in and out of the bundle
#
# lock   ~/.secrets.env  -> server/secrets/secrets.enc  (then commit it)
# unlock the reverse, which is what setup.sh offers on a new machine.
srvlock()   { "$SRV_DIR/secrets.sh" lock   "$@" }
srvunlock() { "$SRV_DIR/secrets.sh" unlock "$@" }

# Old names, still in muscle memory and in a few older scripts.
alias dotinfo=srvinfo
alias dotsync=srvsync
